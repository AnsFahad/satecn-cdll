# ACN course project (Project ID 22): reproduction of CDLL-SATECN (Wu et al., IEEE TWC 2026)

Advanced Computer Networks, Department of CSE, NIT Warangal. Guide: Dr. Venkatarami Reddy Chintapalli.

| Team member | Roll number |
|---|---|
| Vedant Amit Agrawal | 23CSB0A08 |
| Abu Fahad Ansari | 23CSB0A45 |
| Shwetang Wasnik | 23CSB0A55 |

Code repository: https://github.com/AnsFahad/satecn-cdll

This archive contains a from-scratch implementation and experimental reproduction of
"Lifelong Learning-Based SDN Design for Dynamic Configuration and Resource Allocation in
Satellite-Terrestrial Networks" (Wu, Wang, Lorenzo, Samarakoon, Liu; IEEE Transactions on Wireless
Communications, 2026; DOI 10.1109/TWC.2026.3716226).

## Contents

| Folder | What is inside |
|---|---|
| `source_code/` | Python implementation (simulator, NAC / MSR-NAC / ELLA / CDLL, experiments), config, Starlink TLE data, tests, README with run instructions, RESULTS.md |
| `report/` | LaTeX source (`main.tex` and its `\input` files, `references.bib`, `figures/`, `tables/`) and the compiled `project_report.pdf` |
| `presentations/` | `initial_presentation.pptx`, `final_presentation.pptx`, and PDF versions in `pdf_versions/` |
| `experiments/` | Results of the full run used in the report: `results/` (JSON + CSV), `graphs/` (PNG), `logs/run_all.log` |
| `windows_setup/` | `setup_project.ps1`: recreates `source_code/` file by file from PowerShell |

## Quick start (Windows PowerShell)

```powershell
cd source_code
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m pytest -q                                          # 5 tests
python scripts/run_experiments.py --exp all --quick --workers 4   # smoke test, a few minutes
python scripts/run_experiments.py --exp all --workers 4           # full run (about 40 min on 2 cores)
python scripts/make_figures.py
```

## Rebuilding the report

```powershell
cd report
pdflatex main.tex; bibtex main; pdflatex main.tex; pdflatex main.tex
```

## Headline result

The simulator reproduces the paper's satellite-visibility statistic exactly (2.73 visible Starlink satellites),
and several qualitative findings reproduce: MSR-NAC beats NAC in every domain, cross-domain sharing beats
within-domain sharing, the AoI-energy trade-off over beta, scalability trends, and no catastrophic forgetting.
The large CDLL gains reported in the paper (up to 70% lower penalty, 8x faster convergence) do not reproduce.
In this implementation an independent MSR-NAC learner performs as well as or better than CDLL in 5 of 6 domains.
See `source_code/RESULTS.md` and Chapters 7-8 of the report.
