﻿# Recreates the project files in the current directory (run from the project root).
# Usage:  powershell -ExecutionPolicy Bypass -File .\setup_project.ps1
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding $false
function Write-ProjectFile([string]$Path, [string]$Content) {
    $full = Join-Path (Get-Location) $Path
    $dir = Split-Path $full -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($full, (($Content -replace "`r`n", "`n") + "`n"), $utf8)
    Write-Host "wrote $Path"
}

Write-ProjectFile '.gitignore' @'
__pycache__/
*.pyc
.venv/
venv/
.pytest_cache/
experiments/checkpoints/
*.aux
*.log
*.out
*.toc
*.synctex.gz
.vscode/
.DS_Store
'@

Write-ProjectFile 'README.md' @'
# CDLL-SATECN: reproduction of "Lifelong Learning-Based SDN Design for Dynamic Configuration and Resource Allocation in Satellite-Terrestrial Networks"

This repository re-implements the system model and the learning algorithm of

> Y. Wu, N. Wang, B. Lorenzo, S. Samarakoon, B. Liu, "Lifelong Learning-Based SDN Design for Dynamic
> Configuration and Resource Allocation in Satellite-Terrestrial Networks," *IEEE Transactions on Wireless
> Communications*, 2026, DOI 10.1109/TWC.2026.3716226.

and re-runs the paper's evaluation (Figs. 3-9, Table V) plus ablations.

Advanced Computer Networks course project (Project ID 22), Department of CSE, NIT Warangal,
under the guidance of Dr. Venkatarami Reddy Chintapalli.

| Team member | Roll number |
|---|---|
| Vedant Amit Agrawal | 23CSB0A08 |
| Abu Fahad Ansari | 23CSB0A45 |
| Shwetang Wasnik | 23CSB0A55 | The paper provides no code; everything
here was written from the paper's equations. Parameters the paper does not state are marked `[assumed]` in
`configs/default.yaml` and listed under [Deviations](#deviations-from-the-paper).

## Features

- Slotted SATECN simulator (IoT / 2 UAVs / 18 Starlink LEOs): Poisson task arrivals, no task splitting (Eq. 1),
  local and remote computing delay and energy (Eqs. 2-7), air-to-ground and LEO uplink rates (Eqs. 8-10),
  queue evolution (Eqs. 11-12), AoI (Eq. 14) and the AoI-energy penalty (Eq. 15).
- Real Starlink geometry: CelesTrak TLEs propagated with SGP4 and screened as in Sec. V-A
  (55 deg minimum elevation, 90 s continuous visibility). The screened set gives **2.73 visible satellites on
  average, the value the paper reports**.
- The six RL domains of Table II, with heterogeneous policy dimensions (3 to 15 parameters).
- Learners: episodic NAC, MSR-NAC (NAC with n-step returns), MSR-NAC-ELLA (within-domain lifelong learning),
  MSR-NAC-CDLL (cross-domain lifelong learning, Algorithm 1, Eqs. 20-25), and an exhaustive grid-search reference.
- One script per experiment and one script for all figures and tables; unit tests.

## Architecture

```
configs/default.yaml        every parameter, tagged [paper] or [assumed]
data/starlink_screened.txt  the 18 screened Starlink TLEs used by the simulator
src/satecn/
  orbits.py       TLE + SGP4 propagation, elevation/range, screening, synthetic fallback
  channel.py      Eqs. 8-10
  domains.py      Table II domains, RL task sampling (Eq. 17)
  environment.py  the slotted simulator (Eqs. 1-15)
  policy.py       softmax executor head + logit-normal resource heads, score function
  learners.py     roll-outs, NAC, MSR-NAC, Fisher / Hessian, natural step
  lifelong.py     CDLL knowledge base (L, Psi_g, s_k; Eqs. 22-25) and the ELLA baseline
  trainer.py      Algorithm 1 loop over an interleaved task stream
  exhaustive.py   grid-search baseline
  experiments.py  Figs. 3-9, Table V, ablations
scripts/
  run_experiments.py   run experiments -> experiments/results/*.json
  make_figures.py      figures -> experiments/graphs, tables -> experiments/results/*.csv
  screen_tle.py        rebuild data/starlink_screened.txt from a full CelesTrak TLE file
tests/test_core.py     unit tests
```

## Technology stack

Python 3.10+ (tested on 3.12 and 3.13) with NumPy, Matplotlib, PyYAML and sgp4. CPU only; no GPU or deep-learning framework is needed
(policies are linear with at most 15 parameters).

## Installation (Windows PowerShell)

```powershell
git clone https://github.com/AnsFahad/satecn-cdll.git
cd satecn-cdll
python -m venv .venv
.\.venv\Scripts\Activate.ps1
# if activation is blocked:  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m pytest -q
```

Linux/macOS: `python3 -m venv .venv && source .venv/bin/activate`, then the same `pip`/`pytest` commands.

## Dataset preparation

This is a simulation study, so there is no dataset to download. The only external data is the Starlink TLE
snapshot, already screened and included in `data/starlink_screened.txt`. To rebuild it from a fresh snapshot:

```powershell
Invoke-WebRequest "https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=tle" -OutFile starlink_full.txt
python scripts/screen_tle.py --tle starlink_full.txt --start 2026-11-08T00:00:00
```

A fresh snapshot will select different satellites; update `leo.window_start_utc` in the config to the
start time the script prints. If `sgp4` is missing, the simulator falls back to synthetic overhead passes and
prints a notice.

## Execution

```powershell
# smoke test of every experiment at reduced size (about 5 minutes)
python scripts/run_experiments.py --exp all --quick --workers 4
# full reproduction (3 seeds x 4 algorithms x 24 tasks x 200 iterations, then all other experiments)
python scripts/run_experiments.py --exp all --workers 4
# single experiments
python scripts/run_experiments.py --exp main --seeds 0 --workers 4
python scripts/run_experiments.py --exp jumpstart,beta --workers 4
# figures and CSV tables from whatever results exist
python scripts/make_figures.py
```

`system`, `scalability` and `continual` reuse the agents trained by `main` (saved in `experiments/checkpoints`),
so run `main` first.

## Training and evaluation

One *iteration* visits all 24 tasks (4 per domain) in random order. Each visit rolls out one 120-slot episode
(the paper's learning round is 120-150 s), with all IoTs of the task sharing its policy, followed by one update.
Learning curves record the penalty of that exploring, on-policy episode. Metrics: penalty, AoI and scaled energy
per IoT per slot; jumpstart; convergence speedup relative to NAC; forgetting on old tasks.

## Results

See `RESULTS.md` (generated numbers and a comparison with the paper) and `experiments/graphs/`.

## Deviations from the paper

| Item | Paper | Here | Why |
|---|---|---|---|
| Arrival rate | 6-20 tasks/s per IoT | x0.05 (0.3-1.0 tasks/s) | 6-20 tasks/s of 1.2 MB tasks is ~100x the uplink and CPU capacity; Fig. 8b implies near-capacity load |
| LEO altitude filter | 520-580 km | 440-600 km | Starlink shells were lowered to ~480 km after the paper; 520-580 km now selects almost nothing |
| Ground site | not given | 42.37 N, 72.52 W (Amherst, MA) | authors' institution |
| Policy form | "compact, normalised" | softmax executor head + logit-normal resource heads, features [1, AoI, D_rem] | clipped Gaussians gave zero gradient outside [0,1] |
| MSR-NAC | NAC + n-step returns | critic with horizon/backlog features, n = 40, gamma = 1, fixed-KL natural step | details not given; discounting below 1 biased learning towards myopic energy savings |
| Hessian H_k | "estimate from PG" | Fisher information, normalised + 0.01 I | standard curvature choice for natural-gradient methods |
| KB step sizes | eta_L, eta_Psi | relative steps divided by a Lipschitz bound | raw steps diverged |
| s_k update | current task only | Lasso re-solved for all stored tasks after each update | otherwise changes to the shared L move other tasks' policies |
| New task init | s_k <- rand | mean code of known tasks | gives the jumpstart the paper measures; ablation included |
| Energy scale epsilon | not given | 1.0 | makes the AoI and energy terms comparable at beta = 0.8 |
| Exhaustive search | "optimum" | grid over stationary decisions (960 points in domain 6) | true optimum over state-dependent policies is intractable |
| Control-plane overhead (Table V) | measured | modelled (message sizes and link rates in `experiments.py`) | no SDN testbed |

## Limitations

- Simulation only. The channel parameters marked `[assumed]` change the absolute numbers.
- The paper's training details (learning rates, h, d_base, n, episodes per iteration) are unknown; ours were
  chosen once for stable learning and then fixed for every algorithm. They were not tuned per method.
- Learning curves are on-policy with exploration noise, so they sit above the deterministic grid-search line.

## Citation

```bibtex
@article{wu2026cdll,
  author  = {Wu, Yinxuan and Wang, Ning and Lorenzo, Beatriz and Samarakoon, Sumudu and Liu, Bing},
  title   = {Lifelong Learning-Based {SDN} Design for Dynamic Configuration and Resource Allocation in Satellite-Terrestrial Networks},
  journal = {IEEE Transactions on Wireless Communications},
  year    = {2026},
  doi     = {10.1109/TWC.2026.3716226}
}
```
'@

Write-ProjectFile 'RESULTS.md' @'
# Results

All numbers below were produced by `python scripts/run_experiments.py --exp all` followed by
`python scripts/make_figures.py` (3 seeds unless stated). Figures are in `experiments/graphs/`.
Paper values are from Wu et al., IEEE TWC 2026.

## Penalty at the end of training (last 10 of 200 iterations)
| algorithm | D1 | D2 | D3 | D4 | D5 | D6 | all |
|---|---|---|---|---|---|---|---|
| MSR-NAC-CDLL | 27.81 | 25.45 | 18.74 | 20.12 | 18.16 | 19.60 | 21.65 |
| MSR-NAC-ELLA | 29.17 | 25.55 | 18.73 | 22.13 | 19.58 | 18.22 | 22.23 |
| MSR-NAC | 26.40 | 24.53 | 18.22 | 18.20 | 18.41 | 17.12 | 20.48 |
| NAC | 28.26 | 25.04 | 19.89 | 21.69 | 20.36 | 19.83 | 22.51 |

## Domain-6 learning-curve summary (Fig. 3)
| algorithm | first5_iters | last10_iters | mean_200 |
|---|---|---|---|
| MSR-NAC-CDLL | 21.40 | 19.60 | 20.02 |
| MSR-NAC-ELLA | 19.93 | 18.22 | 18.78 |
| MSR-NAC | 19.45 | 17.12 | 18.07 |
| NAC | 19.67 | 19.83 | 19.74 |
| Exhaustive search (grid, deterministic) | - | 14.88 | - |

## Convergence speedup relative to NAC (Fig. 7)
| algorithm | D1 | D2 | D3 | D4 | D5 | D6 | mean |
|---|---|---|---|---|---|---|---|
| MSR-NAC-CDLL | 0.36 | 0.35 | 1.66 | 0.22 | 0.69 | 0.41 | 0.61 |
| MSR-NAC-ELLA | 1.03 | 0.02 | 4.72 | 3.12 | 0.34 | 0.78 | 1.67 |
| MSR-NAC | 2.78 | 3.50 | 2.99 | 2.25 | 1.00 | 2.26 | 2.46 |
| NAC | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |

## Jumpstart on unseen tasks, % penalty reduction vs MSR-NAC from random init (Fig. 6)
| algorithm | D1 | D2 | D3 | D4 | D5 | D6 | mean |
|---|---|---|---|---|---|---|---|
| MSR-NAC-CDLL | 3.1 | -6.0 | 5.5 | -5.1 | -7.2 | -4.9 | -2.4 |
| MSR-NAC-ELLA | -0.8 | -8.3 | 0.5 | -9.8 | -7.1 | -9.2 | -5.8 |

## AoI-energy trade-off vs beta, CDLL on domain-6 tasks, seed 0 (Fig. 5)
| beta | aoi | energy | penalty |
|---|---|---|---|
| 0.0 | 38.953 | 1.996 | 1.996 |
| 0.2 | 24.117 | 3.012 | 7.233 |
| 0.4 | 23.169 | 5.635 | 12.649 |
| 0.6 | 18.734 | 15.568 | 17.468 |
| 0.7 | 17.560 | 19.127 | 18.030 |
| 0.8 | 16.869 | 21.959 | 17.887 |
| 0.85 | 16.606 | 22.981 | 17.562 |
| 0.9 | 16.504 | 24.418 | 17.296 |
| 0.95 | 16.235 | 26.278 | 16.737 |
| 1.0 | 16.127 | 27.131 | 16.127 |

## Scalability, U = N/5, L = 18, 600 slots (Table V; control-plane columns are modelled)
| N | aoi | total_energy_per_slot | energy_per_iot_per_slot | ctrl_energy_pct_modelled | ctrl_latency_ms_modelled | sim_wall_s |
|---|---|---|---|---|---|---|
| 80 | 98.069 | 875.302 | 10.941 | 0.00403 | 0.213 | 0.833 |
| 120 | 89.086 | 1303.902 | 10.866 | 0.00422 | 0.233 | 1.225 |
| 160 | 93.512 | 1682.448 | 10.515 | 0.00413 | 0.254 | 2.091 |
| 200 | 86.377 | 2043.199 | 10.216 | 0.00432 | 0.274 | 2.536 |
| 240 | 87.154 | 2429.022 | 10.121 | 0.00429 | 0.295 | 2.967 |
| 280 | 87.909 | 2763.173 | 9.868 | 0.00426 | 0.315 | 3.870 |

## Continual learning on new tasks 25-28 and forgetting on tasks 1-24 (Fig. 9)
| algorithm | new_first_encounter | new_subsequent | old_tasks_before | old_tasks_after |
|---|---|---|---|---|
| MSR-NAC-CDLL | 18.57 | 19.10 | 21.62 | 21.61 |
| MSR-NAC-ELLA | 18.56 | 18.26 | 22.20 | 22.19 |
| MSR-NAC | 19.43 | 19.23 | 20.48 | 20.48 |
| NAC | 19.01 | 19.03 | 22.52 | 22.52 |

## Ablations (seed 0, 100 iterations)
| variant | mean_penalty | final_penalty |
|---|---|---|
| n_step=1 | 22.527 | 23.754 |
| n_step=10 | 18.745 | 18.616 |
| n_step=40 (default) | 18.993 | 19.207 |
| n_step=120 (MC) | 18.929 | 18.671 |
| CDLL h=4 | 23.705 | 23.398 |
| CDLL h=8 (default) | 22.519 | 22.188 |
| CDLL h=15 | 22.746 | 22.962 |
| CDLL s_k=rand (Alg.1) | 22.619 | 21.770 |
| CDLL no refit | 24.354 | 25.630 |

## Comparison with the paper

| Claim | Paper | Ours | Verdict |
|---|---|---|---|
| Mean visible LEOs after screening | 2.73 | 2.73 | reproduced |
| MSR-NAC beats NAC in every domain | yes | yes (-6.9% over training, -9.0% at end) | reproduced |
| CDLL beats single-domain ELLA | most domains | 5 of 6 domains | reproduced |
| Up to 70% lower AoI/energy | up to 70% | largest gap ~18% | not reproduced |
| Convergence speedup vs NAC | > 8x | 0.61x (CDLL), 2.5x (MSR-NAC) | not reproduced |
| Jumpstart vs MSR-NAC | 27-67% | -2.4% (CDLL), -5.8% (ELLA) | not reproduced |
| AoI from beta=0 to beta=1 | 38.58 -> 20.54 | 38.95 -> 16.13 | reproduced |
| Win-win region beta in [0, 0.85] | AoI and energy both fall | energy rises | not reproduced |
| LEOs help (domain 5 -> 6) | 61.9 -> 48.5 | 17.9 -> 19.7 | not reproduced |
| Scaling 80 -> 280 IoTs | AoI +3%, energy/IoT -29% | AoI -10%, energy/IoT -10% | trend reproduced |
| No catastrophic forgetting | qualitative | old-task change <= 0.01 | reproduced |

Why the numbers differ, and the limitations of this study, are discussed in Chapter 8 of the report.
'@

Write-ProjectFile 'configs\default.yaml' @'
# SATECN + CDLL reproduction config. Values marked [paper] come from Table IV / Sec. V-A;
# values marked [assumed] are implementation decisions documented in README/report.

seed: 2026

area:
  size_m: 1000.0            # [paper] 1000 x 1000 m terrestrial area
  lat: 42.3732              # [assumed] ground site (UMass Amherst) for LEO geometry
  lon: -72.5199

sim:
  slot_s: 1.0               # [paper] slot length 1 s
  episode_slots: 120        # [paper] learning round 120-150 s -> one trajectory window
  aoi_norm: 50.0            # [assumed] state normalisation of AoI
  drem_norm_mb: 20.0        # [assumed] state normalisation of remaining data (MB)

iot:
  task_mb_mean: 1.2         # [paper] D_i ~ N(1.2, 0.6^2) MB
  task_mb_std: 0.6
  task_mb_min: 0.2          # [assumed] truncate the normal at 0.2 MB
  per_task_cv: 0.1          # [assumed] D_i^v(t) ~ N(D_i, (0.1 D_i)^2) "sampled around D_i"
  lambda_range: [6.0, 20.0] # [paper] tasks / s
  lambda_scale: 0.05        # [assumed] rescale so offered load ~ service capacity (Fig. 8b regime); see README
  rho_range: [180.0, 284.0] # [paper] cycles / bit
  eps_max: 1.0e+9            # [paper] cycles / slot
  alpha: 1.0e-25            # [paper] J / cycle^3
  p_max_uav: 0.1            # [paper] W
  p_max_leo: 2.0            # [paper] W
  xi_cpt: 1.0               # [paper]
  xi_tr: 1.0                # [assumed] not given in paper

uav:
  n: 2                      # [paper]
  altitude_m: 30.0          # [paper]
  eps_max: 2.0e+9            # [paper]
  alpha: 1.0e-25            # [paper]
  xi_cpt: 0.75              # [paper]
  speed_mps: [5.0, 15.0]    # [assumed] random-waypoint speed
  bandwidth_hz: 1.0e+6       # [paper]
  carrier_hz: 2.0e+9         # [assumed]
  eta_los_db: 1.0           # [assumed] excess loss, Zhu et al. [33]-style A2G model
  eta_nlos_db: 20.0
  env_a: 9.61               # [assumed] urban LoS-probability parameters
  env_b: 0.16
  noise_dbm_hz: -174.0
  noise_figure_db: 10.0     # [assumed]

leo:
  n_sats: 18                # [paper]
  use_tle: true
  tle_file: data/starlink_screened.txt
  window_start_utc: "2026-11-08T00:30:00"
  window_s: 600             # [paper] 600 s screening window
  min_elev_deg: 55.0        # [paper]
  eps_max: 1.0e+10           # [paper]
  alpha: 1.0e-28            # [paper]
  xi_cpt: 0.6               # [paper]
  bandwidth_hz: 1.0e+6       # [paper]
  carrier_hz: 2.0e+9         # [assumed] S-band direct-to-device uplink
  iot_gain_dbi: 0.0         # [assumed]
  sat_gain_dbi: 22.0        # [assumed] calibrated to "hundreds of kbit/s to several Mbit/s"
  noise_dbm_hz: -174.0
  noise_figure_db: 3.0
  rician_k: 10.0            # [assumed] small-scale fading H_{i,l}(t)

objective:
  beta: 0.8                 # [paper]
  energy_scale: 1.0         # [assumed] epsilon in Eq. (15); not given in paper

policy:
  sigma: 0.5                # [assumed] exploration std of the logit-normal resource heads
  init_scale: 1.0           # [assumed] theta ~ U(0, init_scale) for learning from scratch

learner:
  iterations: 200           # [paper] 200 training iterations
  episodes_per_iter: 1      # trajectories per iteration (each episode = all IoTs of the task)
  gamma: 1.0                # [assumed] undiscounted within the finite trajectory window
  n_step: 40                # [assumed] MSR-NAC n-step horizon
  step_size: 0.2            # [assumed] fixed-KL natural-gradient step
  step_decay: 0.995
  ridge: 1.0e-3

lifelong:
  d_base: 15                # [assumed] shared base dimension (= largest domain dimension)
  h: 8                      # [assumed] number of latent components
  eta_L: 0.5                # [assumed] relative step (x 1/Lipschitz bound) for Eq. (23)
  eta_psi: 0.5              # [assumed] relative step for Eq. (24)
  mu1: 0.01                 # l1 on s_k
  mu2: 1.0e-3               # Frobenius on Psi_g
  mu3: 1.0e-3               # Frobenius on L
  kb_steps: 10              # gradient steps on (L, Psi) per task update
  warm_start: true          # [assumed] new task s_k initialised from same-domain tasks (Alg. 1 uses rand)
  hessian_reg: 1.0e-2

tasks:
  per_domain: 4             # [paper] tasks 1-24 from 6 domains
  new_domain6: 4            # [paper] tasks 25-28 from domain 6
'@

Write-ProjectFile 'data\starlink_screened.txt' @'
STARLINK-3527
1 51726U 22016N   26311.68642954  .00022759  00000+0  11840-2 0  9999
2 51726  53.2136 302.3658 0002438  52.8421 307.2796 15.15974447260334
STARLINK-5059
1 53912U 22119AC  26311.28440410  .00000005  00000+0  18420-4 0  9994
2 53912  53.1604 303.7590 0001277  61.7197 298.3923 15.08830618228453
STARLINK-6157
1 56379U 23061F   26311.22241775  .00000084  00000+0  12585-4 0  9991
2 56379  43.0033 268.0550 0001538 264.0331  96.0345 15.27576241194941
STARLINK-5356
1 56418U 23061AW  26311.54902152 -.00000102  00000+0  58411-5 0  9994
2 56418  43.0057 247.8600 0001418 265.2496  94.8194 15.27574828194109
STARLINK-30389
1 57783U 23134N   26311.83334491  .00062716  00000+0  22706-2 0  9991
2 57783  43.0013 264.4089 0001473 268.0522 194.6408 15.27561325  5831
STARLINK-30838
1 58211U 23170F   26311.83334491  .00041567  00000+0  15129-2 0  9990
2 58211  43.0008 260.9048 0001786 263.2489 225.0887 15.27549110  5832
STARLINK-30813
1 58213U 23170H   26311.83334491  .00039741  00000+0  14469-2 0  9999
2 58213  43.0004 260.9537 0001982 250.1356 216.9520 15.27557039  5831
STARLINK-30818
1 58217U 23170M   26311.35491756 -.00000747  00000+0 -17611-4 0  9998
2 58217  43.0016 263.6400 0001320 257.6219 102.4485 15.27579034167414
STARLINK-31661
1 59735U 24090F   26311.54830170  .00000315  00000+0  20965-4 0  9999
2 59735  43.0022 244.9172 0001174 284.8529  75.2193 15.27591142140663
STARLINK-32452
1 61961U 24210C   26311.21925148  .00027772  00000+0  10136-2 0  9994
2 61961  43.0019 243.0647 0001449 274.8003  85.2683 15.27624082112081
STARLINK-32514
1 61965U 24210G   26311.75004630  .00060567  00000+0  21938-2 0  9992
2 61965  43.0016 240.1167 0001737 268.1806 113.0733 15.27560013  5871
STARLINK-34106
1 63907U 25095T   26311.54949397  .00014178  00000+0  52362-3 0  9990
2 63907  43.0037 244.3602 0001017 279.8055  80.2681 15.27588446 84928
STARLINK-33974
1 63954U 25099C   26311.22011730  .00021829  00000+0  79981-3 0  9999
2 63954  43.0070 246.9297 0002198 246.8216 113.2405 15.27604349 84426
STARLINK-34084
1 63970U 25099U   26311.22382385  .00027258  00000+0  99523-3 0  9990
2 63970  43.0002 246.0942 0001478 273.3920  86.6763 15.27618162 84433
STARLINK-34190
1 64078U 25107Q   26311.61685901  .00022803  00000+0  83469-3 0  9996
2 64078  43.0021 269.5718 0001607 272.9610  87.1057 15.27615545 83275
STARLINK-34351
1 64387U 25127T   26311.55159067  .00043342  00000+0  15731-2 0  9990
2 64387  43.0053 247.8962 0002893 331.2445  28.8247 15.27624917 79615
STARLINK-34198
1 64388U 25127U   26311.55030242  .00019326  00000+0  70961-3 0  9996
2 64388  43.0077 247.8648 0001284 260.7873  99.2834 15.27596885 79613
STARLINK-34279
1 64389U 25127V   26311.66670139  .00033490  00000+0  12213-2 0  9997
2 64389  43.0026 248.0487 0001488 247.3573  46.8925 15.27571099  5816
'@

Write-ProjectFile 'requirements.txt' @'
numpy>=1.24
matplotlib>=3.7
PyYAML>=6.0
sgp4>=2.22
pytest>=7.0
'@

Write-ProjectFile 'scripts\make_figures.py' @'
"""Turn experiments/results/*.json into figures (experiments/graphs) and tables (experiments/results).

Usage: python scripts/make_figures.py
"""
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "experiments" / "results"
FIG = ROOT / "experiments" / "graphs"
FIG.mkdir(parents=True, exist_ok=True)

ALGOS = ["msr_nac_cdll", "msr_nac_ella", "msr_nac", "nac"]
LABEL = {"msr_nac_cdll": "MSR-NAC-CDLL", "msr_nac_ella": "MSR-NAC-ELLA", "msr_nac": "MSR-NAC", "nac": "NAC"}
COLOR = {"msr_nac_cdll": "#2a78d6", "msr_nac_ella": "#eb6834", "msr_nac": "#1baf7a", "nac": "#eda100"}
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"
DOMS = [1, 2, 3, 4, 5, 6]

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False, "savefig.dpi": 200, "savefig.bbox": "tight",
})
SUMMARY = {}


def load(name):
    p = RES / f"{name}.json"
    if not p.exists():
        print(f"[skip] {p.name} missing")
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def smooth(x, w=10):
    x = np.asarray(x, float)
    if len(x) < w:
        return x
    c = np.cumsum(np.insert(x, 0, 0.0))
    head = c[1:w] / np.arange(1, w)
    return np.concatenate([head, (c[w:] - c[:-w]) / w])


def write_csv(name, header, rows):
    with open(RES / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        wr.writerows(rows)


def bars(ax, data, algos, ylabel, title):
    """Grouped bars per domain; data[algo] = (means[6], stds[6])."""
    n = len(algos)
    width = 0.8 / n
    x = np.arange(len(DOMS))
    for j, a in enumerate(algos):
        m, s = data[a]
        ax.bar(x + (j - (n - 1) / 2) * width, m, width * 0.92, yerr=s, color=COLOR[a], label=LABEL[a],
               error_kw={"elinewidth": 0.8, "ecolor": MUTED, "capsize": 2})
    ax.set_xticks(x, [f"D{g}" for g in DOMS])
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=10, color=INK)
    ax.grid(axis="x", visible=False)


# ------------------------------------------------------------------------------------------- main
def per_domain_curves(main, algo, metric):
    """{seed: {g: mean curve over that domain's tasks}}"""
    out = {}
    for s in main["seeds"]:
        h = main["runs"][f"{algo}|{s}"]["hist"]
        out[s] = {g: np.mean([h[k][metric] for k, gg in main["task_domain"].items() if gg == g], axis=0)
                  for g in DOMS}
    return out


def fig_main(main, exh):
    iters = main["iterations"]
    # Fig. 3: domain-6 convergence
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    rows = []
    for a in ALGOS:
        cur = np.array([per_domain_curves(main, a, "penalty")[s][6] for s in main["seeds"]])
        m, sd = smooth(cur.mean(0), 5), smooth(cur.std(0), 5)
        ax.plot(np.arange(1, iters + 1), m, color=COLOR[a], lw=2, label=LABEL[a])
        ax.fill_between(np.arange(1, iters + 1), m - sd, m + sd, color=COLOR[a], alpha=0.12, lw=0)
        rows.append([LABEL[a], f"{cur.mean(0)[:5].mean():.2f}", f"{cur.mean(0)[-10:].mean():.2f}", f"{cur.mean():.2f}"])
    if exh:
        ev = np.mean([r["eval"]["penalty"] for r in exh["runs"].values()])
        ax.axhline(ev, color=MUTED, ls="--", lw=1.5, label="Exhaustive search (grid)")
        rows.append(["Exhaustive search (grid, deterministic)", "-", f"{ev:.2f}", "-"])
        SUMMARY["exhaustive_d6"] = ev
    ax.set_xlabel("Training iteration")
    ax.set_ylabel("Average penalty (domain 6)")
    ax.set_title("Average penalty vs. iterations, RL domain 6 (mean \u00b1 std over seeds)", fontsize=10)
    ax.legend(ncol=2, fontsize=8)
    fig.savefig(FIG / "fig3_domain6_convergence.png")
    plt.close(fig)
    write_csv("fig3_domain6", ["algorithm", "first5_iters", "last10_iters", "mean_200"], rows)

    # Fig. 4: per-domain averages over all training iterations
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
    rows = []
    for ax, (met, yl, tt) in zip(axs, [("penalty", "Penalty", "(a) System penalty per RL domain"),
                                       ("aoi", "AoI (slots)", "(b) AoI per RL domain"),
                                       ("energy", "Scaled energy cost", "(c) Scaled energy per RL domain")]):
        data = {}
        for a in ALGOS:
            cur = per_domain_curves(main, a, met)
            per_seed = np.array([[cur[s][g].mean() for g in DOMS] for s in main["seeds"]])
            data[a] = (per_seed.mean(0), per_seed.std(0))
            for gi, g in enumerate(DOMS):
                rows.append([met, LABEL[a], g, f"{per_seed.mean(0)[gi]:.3f}", f"{per_seed.std(0)[gi]:.3f}"])
        bars(ax, data, ALGOS, yl, tt)
        SUMMARY[f"fig4_{met}"] = {LABEL[a]: data[a][0].round(2).tolist() for a in ALGOS}
    axs[0].legend(fontsize=8, ncol=2)
    fig.savefig(FIG / "fig4_domain_comparison.png")
    plt.close(fig)
    write_csv("fig4_per_domain", ["metric", "algorithm", "domain", "mean", "std_over_seeds"], rows)

    # final-iteration (converged) per-domain penalty
    rows = []
    fin = {}
    for a in ALGOS:
        cur = per_domain_curves(main, a, "penalty")
        v = np.array([[cur[s][g][-10:].mean() for g in DOMS] for s in main["seeds"]])
        fin[a] = v.mean(0)
        rows.append([LABEL[a]] + [f"{x:.2f}" for x in v.mean(0)] + [f"{v.mean():.2f}"])
    write_csv("final_penalty_per_domain", ["algorithm"] + [f"D{g}" for g in DOMS] + ["all"], rows)
    SUMMARY["final_penalty"] = {LABEL[a]: fin[a].round(2).tolist() for a in ALGOS}

    # Fig. 7: convergence speedup relative to NAC
    fig, ax = plt.subplots(figsize=(6.6, 3.6))
    data, rows = {}, []
    for a in ALGOS:
        sp = []
        for s in main["seeds"]:
            row = []
            for g in DOMS:
                nac = smooth(per_domain_curves(main, "nac", "penalty")[s][g], 10)
                target = nac[-20:].mean()
                def conv(c):
                    idx = np.nonzero(smooth(c, 10) <= target)[0]
                    return (idx[0] + 1) if len(idx) else iters
                row.append(conv(per_domain_curves(main, "nac", "penalty")[s][g]) /
                           conv(per_domain_curves(main, a, "penalty")[s][g]))
            sp.append(row)
        sp = np.array(sp)
        data[a] = (sp.mean(0), sp.std(0))
        rows.append([LABEL[a]] + [f"{x:.2f}" for x in sp.mean(0)] + [f"{sp.mean():.2f}"])
    bars(ax, data, ALGOS, "Speedup vs. NAC (\u00d7)", "Convergence speedup relative to NAC")
    ax.axhline(1, color=MUTED, lw=0.8)
    ax.legend(fontsize=8, ncol=2)
    fig.savefig(FIG / "fig7_convergence_speedup.png")
    plt.close(fig)
    write_csv("fig7_speedup", ["algorithm"] + [f"D{g}" for g in DOMS] + ["mean"], rows)
    SUMMARY["speedup"] = {r[0]: r[1:] for r in rows}
    SUMMARY["wall_s"] = {k: v["wall_s"] for k, v in main["runs"].items()}
    SUMMARY["recon_error"] = {k: v.get("recon_error") for k, v in main["runs"].items() if "recon_error" in v}


# ------------------------------------------------------------------------------------------- others
def fig_jumpstart(js):
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    data, rows = {}, []
    for a in ("msr_nac_cdll", "msr_nac_ella"):
        red = np.array([[100 * (r["msr_nac"][str(g)] - r[a][str(g)]) / r["msr_nac"][str(g)] for g in DOMS]
                        for r in js["runs"].values()])
        data[a] = (red.mean(0), red.std(0))
        rows.append([LABEL[a]] + [f"{x:.1f}" for x in red.mean(0)] + [f"{red.mean():.1f}"])
    bars(ax, data, ["msr_nac_cdll", "msr_nac_ella"], "Penalty reduction vs. MSR-NAC (%)",
         f"Jumpstart on unseen tasks after {js['pre_rounds']} pre-training rounds")
    ax.axhline(0, color=MUTED, lw=0.8)
    ax.legend(fontsize=8)
    fig.savefig(FIG / "fig6_jumpstart.png")
    plt.close(fig)
    write_csv("fig6_jumpstart", ["algorithm"] + [f"D{g}" for g in DOMS] + ["mean"], rows)
    SUMMARY["jumpstart_pct"] = {r[0]: r[1:] for r in rows}


def fig_beta(bs):
    betas = bs["betas"]
    seeds = sorted({k.split("|")[1] for k in bs["runs"]})
    agg = {k: np.array([np.mean([bs["runs"][f"{b}|{s}"][k] for s in seeds]) for b in betas]) for k in ("aoi", "energy", "penalty")}
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
    axs[0].plot(agg["aoi"], agg["energy"], "-o", color=COLOR["msr_nac_cdll"], ms=6, lw=1.5)
    for b, x, y in zip(betas, agg["aoi"], agg["energy"]):
        axs[0].annotate(f"{b:g}", (x, y), textcoords="offset points", xytext=(4, 4), fontsize=8, color=MUTED)
    axs[0].set_xlabel("Average AoI")
    axs[0].set_ylabel("Average scaled energy")
    axs[0].set_title("(a) AoI-energy trade-off across \u03b2", fontsize=10)
    axs[1].plot(betas, agg["aoi"], "-o", color=COLOR["msr_nac_cdll"], ms=6, lw=2)
    axs[1].set_xlabel("\u03b2")
    axs[1].set_ylabel("Average AoI")
    axs[1].set_title("(b) AoI vs. \u03b2", fontsize=10)
    axs[2].plot(betas, agg["energy"], "-o", color=COLOR["msr_nac_ella"], ms=6, lw=2)
    axs[2].set_xlabel("\u03b2")
    axs[2].set_ylabel("Average scaled energy")
    axs[2].set_title("(c) Energy vs. \u03b2", fontsize=10)
    for ax in axs[1:]:
        ax.axvspan(0.8, 0.9, color=GRID, alpha=0.6, lw=0)
    fig.savefig(FIG / "fig5_beta_sweep.png")
    plt.close(fig)
    write_csv("fig5_beta", ["beta", "aoi", "energy", "penalty"],
              [[b, f"{a:.3f}", f"{e:.3f}", f"{p:.3f}"] for b, a, e, p in zip(betas, agg["aoi"], agg["energy"], agg["penalty"])])
    SUMMARY["beta"] = {str(b): [round(a, 2), round(e, 2)] for b, a, e in zip(betas, agg["aoi"], agg["energy"])}


def fig_system(sysr):
    keys = ["penalty", "aoi", "energy"]
    st_keys = ["gen", "done_iot", "done_uav", "done_leo", "local", "to_uav", "to_leo",
               "e_local", "e_tx_uav", "e_tx_leo", "e_uav", "e_leo"]
    per = {g: {k: [] for k in keys + st_keys} for g in DOMS}
    for r in sysr.values():
        g = r["gid"]
        for k in keys:
            per[g][k].append(r[k])
        for k in st_keys:
            per[g][k].append(r["stats"][k])
    avg = {g: {k: float(np.mean(v)) for k, v in per[g].items()} for g in DOMS}
    fig, axs = plt.subplots(1, 3, figsize=(15, 4))
    x = np.arange(6)
    axs[0].bar(x - 0.2, [avg[g]["penalty"] for g in DOMS], 0.37, color=COLOR["msr_nac_ella"], label="Penalty")
    axs[0].bar(x + 0.2, [avg[g]["aoi"] for g in DOMS], 0.37, color=COLOR["msr_nac_cdll"], label="AoI")
    for i, g in enumerate(DOMS):
        axs[0].text(i - 0.2, avg[g]["penalty"], f"{avg[g]['penalty']:.1f}", ha="center", va="bottom", fontsize=7, color=INK)
        axs[0].text(i + 0.2, avg[g]["aoi"], f"{avg[g]['aoi']:.1f}", ha="center", va="bottom", fontsize=7, color=INK)
    axs[0].set_title("(a) Penalty and AoI, converged CDLL policy", fontsize=10)
    axs[0].legend(fontsize=8)
    parts = [("done_iot", "Completed by IoT", "#2a78d6"), ("done_uav", "Completed by UAV", "#1baf7a"),
             ("done_leo", "Completed by LEO", "#eb6834"), ("local", "Waiting at IoT", "#86b6ef"),
             ("to_uav", "Waiting: to UAV", "#9fdcc4"), ("to_leo", "Waiting: to LEO", "#f5b394")]
    bottom = np.zeros(6)
    for k, lab, c in parts:
        v = np.array([avg[g][k] for g in DOMS])
        axs[1].bar(x, v, 0.6, bottom=bottom, color=c, label=lab, edgecolor="white", linewidth=1)
        bottom += v
    axs[1].plot(x, [avg[g]["gen"] for g in DOMS], "--o", color=INK, ms=4, lw=1, label="Generated tasks")
    axs[1].set_ylabel("Tasks per 120-slot episode")
    axs[1].set_title("(b) Where tasks are completed or waiting", fontsize=10)
    axs[1].legend(fontsize=7, ncol=2)
    eparts = [("e_local", "IoT compute", "#184f95"), ("e_tx_uav", "Tx to UAV", "#0e7a54"),
              ("e_tx_leo", "Tx to LEO", "#a8461f"), ("e_uav", "UAV compute", "#5ec79f"), ("e_leo", "LEO compute", "#f08d63")]
    bottom = np.zeros(6)
    for k, lab, c in eparts:
        v = np.array([avg[g][k] for g in DOMS]) / 1e3
        axs[2].bar(x, v, 0.6, bottom=bottom, color=c, label=lab, edgecolor="white", linewidth=1)
        bottom += v
    axs[2].set_ylabel("Energy per episode (kJ)")
    axs[2].set_title("(c) Energy breakdown", fontsize=10)
    axs[2].legend(fontsize=7)
    for ax in axs:
        ax.set_xticks(x, [f"D{g}" for g in DOMS])
        ax.grid(axis="x", visible=False)
    fig.savefig(FIG / "fig8_system_analysis.png")
    plt.close(fig)
    write_csv("fig8_system", ["domain"] + keys + st_keys, [[g] + [f"{avg[g][k]:.3f}" for k in keys + st_keys] for g in DOMS])
    SUMMARY["system"] = {g: {k: round(avg[g][k], 2) for k in keys + ["gen", "done_iot", "done_uav", "done_leo"]} for g in DOMS}


def table_scal(sc):
    Ns = sorted({int(k.split("|")[0]) for k in sc["runs"]})
    rows = []
    for N in Ns:
        rs = [v for k, v in sc["runs"].items() if int(k.split("|")[0]) == N]
        m = {k: np.mean([r[k] for r in rs]) for k in ("aoi", "total_energy", "energy_per_iot", "ctrl_energy_ratio",
                                                        "ctrl_latency_ms", "sim_wall_s")}
        rows.append([N, f"{m['aoi']:.3f}", f"{m['total_energy']:.3f}", f"{m['energy_per_iot']:.3f}",
                     f"{100 * m['ctrl_energy_ratio']:.5f}", f"{m['ctrl_latency_ms']:.3f}", f"{m['sim_wall_s']:.3f}"])
    write_csv("table5_scalability", ["N", "aoi", "total_energy_per_slot", "energy_per_iot_per_slot",
                                     "ctrl_energy_pct_modelled", "ctrl_latency_ms_modelled", "sim_wall_s"], rows)
    SUMMARY["scalability"] = rows


def fig_continual(ct):
    seeds = sorted({k.split("|")[1] for k in ct["runs"]})
    s0 = seeds[0]
    fig = plt.figure(figsize=(14, 4))
    gs = fig.add_gridspec(1, 3, width_ratios=[2.2, 1.1, 1.2])
    ax = fig.add_subplot(gs[0])
    for a in ALGOS:
        seq = ct["runs"][f"{a}|{s0}"]["seq"]
        y = [e["penalty"] for e in seq]
        ax.plot(np.arange(1, len(y) + 1), y, color=COLOR[a], lw=1.5, label=LABEL[a])
        f = [i for i, e in enumerate(seq) if e["first"]]
        ax.plot(np.array(f) + 1, [y[i] for i in f], "o", color=COLOR[a], ms=8, mec="white", mew=1.5)
    ax.set_xlabel("Encounter index (randomised sequence of new tasks 25-28; dots = first encounter)")
    ax.set_ylabel("Penalty")
    ax.set_title(f"(a) Penalty on new domain-6 tasks (seed {s0})", fontsize=10)
    ax.legend(fontsize=8, ncol=2)
    ax = fig.add_subplot(gs[1])
    data, pos, cols = [], [], []
    for j, a in enumerate(ALGOS):
        first = [e["penalty"] for s in seeds for e in ct["runs"][f"{a}|{s}"]["seq"] if e["first"]]
        sub = [e["penalty"] for s in seeds for e in ct["runs"][f"{a}|{s}"]["seq"] if not e["first"]]
        data += [first, sub]
        pos += [3 * j, 3 * j + 1]
        cols += [COLOR[a], COLOR[a]]
    bp = ax.boxplot(data, positions=pos, widths=0.8, patch_artist=True, showfliers=False)
    for i, (b, c) in enumerate(zip(bp["boxes"], cols)):
        b.set_facecolor(c)
        b.set_alpha(0.9 if i % 2 == 0 else 0.45)
        if i % 2:
            b.set_hatch("//")
    ax.set_xticks([3 * j + 0.5 for j in range(4)], [LABEL[a].replace("MSR-NAC-", "") for a in ALGOS], fontsize=8)
    ax.set_title("(b) First (solid) vs. later (hatched) encounters", fontsize=10)
    ax.grid(axis="x", visible=False)
    ax = fig.add_subplot(gs[2])
    kids = sorted({e["kid"] for e in ct["runs"][f"{ALGOS[0]}|{s0}"]["seq"]})
    M = np.array([[np.mean([e["penalty"] for s in seeds for e in ct["runs"][f"{a}|{s}"]["seq"] if e["kid"] == k])
                   for a in ALGOS] for k in kids])
    im = ax.imshow(M, cmap="Blues", aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{M[i, j]:.1f}", ha="center", va="center", fontsize=8,
                    color="white" if M[i, j] > M.mean() else INK)
    ax.set_xticks(range(4), [LABEL[a].replace("MSR-NAC-", "") for a in ALGOS], fontsize=8)
    ax.set_yticks(range(len(kids)), [f"Task {k}" for k in kids])
    ax.grid(False)
    ax.set_title("(c) Mean penalty per new task", fontsize=10)
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.savefig(FIG / "fig9_continual_learning.png")
    plt.close(fig)
    rows = []
    for a in ALGOS:
        fb = [np.mean(list(ct["runs"][f"{a}|{s}"]["old_before"].values())) for s in seeds]
        fa = [np.mean(list(ct["runs"][f"{a}|{s}"]["old_after"].values())) for s in seeds]
        first = [e["penalty"] for s in seeds for e in ct["runs"][f"{a}|{s}"]["seq"] if e["first"]]
        sub = [e["penalty"] for s in seeds for e in ct["runs"][f"{a}|{s}"]["seq"] if not e["first"]]
        rows.append([LABEL[a], f"{np.mean(first):.2f}", f"{np.mean(sub):.2f}", f"{np.mean(fb):.2f}", f"{np.mean(fa):.2f}"])
    write_csv("fig9_continual", ["algorithm", "new_first_encounter", "new_subsequent", "old_tasks_before",
                                 "old_tasks_after"], rows)
    SUMMARY["continual"] = rows


def fig_ablation(ab):
    names = list(dict.fromkeys(k.split("|")[0] for k in ab["runs"]))
    mean = [np.mean([v["mean"] for k, v in ab["runs"].items() if k.split("|")[0] == n]) for n in names]
    final = [np.mean([v["final"] for k, v in ab["runs"].items() if k.split("|")[0] == n]) for n in names]
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    y = np.arange(len(names))
    ax.barh(y + 0.2, mean, 0.38, color=COLOR["msr_nac_cdll"], label="mean over training")
    ax.barh(y - 0.2, final, 0.38, color=COLOR["msr_nac_ella"], label="last 10 iterations")
    ax.set_yticks(y, names, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel("Average penalty")
    ax.set_title("Ablations (n-step: domains 5-6, MSR-NAC; CDLL: all domains)", fontsize=10)
    ax.legend(fontsize=8)
    fig.savefig(FIG / "fig10_ablation.png")
    plt.close(fig)
    write_csv("ablation", ["variant", "mean_penalty", "final_penalty"],
              [[n, f"{m:.3f}", f"{f:.3f}"] for n, m, f in zip(names, mean, final)])
    SUMMARY["ablation"] = {n: [round(m, 2), round(f, 2)] for n, m, f in zip(names, mean, final)}


def main():
    main_r, exh = load("main"), load("exhaustive")
    if main_r:
        fig_main(main_r, exh)
    for name, fn in [("jumpstart", fig_jumpstart), ("beta_sweep", fig_beta), ("system", fig_system),
                     ("scalability", table_scal), ("continual", fig_continual), ("ablation", fig_ablation)]:
        r = load(name)
        if r:
            fn(r)
    (RES / "summary.json").write_text(json.dumps(SUMMARY, indent=1, default=float), encoding="utf-8")
    print(f"figures -> {FIG}\ntables  -> {RES}")


if __name__ == "__main__":
    sys.exit(main())
'@

Write-ProjectFile 'scripts\run_experiments.py' @'
"""Run the reproduction experiments.

Examples (from the project root):
  python scripts/run_experiments.py --exp all
  python scripts/run_experiments.py --exp main --seeds 0 --iters 50      (quick check)
"""
import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from satecn import experiments as E  # noqa: E402

ORDER = ["main", "exhaustive", "jumpstart", "beta", "system", "scalability", "continual", "ablation"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", default="all", help="comma list of: " + ", ".join(ORDER) + " or all")
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--iters", type=int, default=None, help="override training iterations of the main run")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--quick", action="store_true", help="1 seed, short runs (smoke test, ~5 min)")
    a = ap.parse_args()

    seeds = [int(s) for s in a.seeds.split(",")]
    exps = ORDER if a.exp == "all" else a.exp.split(",")
    cfg = E.load_config(a.config)
    iters = a.iters or cfg["learner"]["iterations"]
    if a.quick:
        seeds, iters = [0], min(iters, 30)
    for name in exps:
        t0 = time.time()
        print(f"--- experiment: {name}", flush=True)
        if name == "main":
            E.run_main(a.config, seeds, iters, a.workers)
        elif name == "exhaustive":
            E.run_exhaustive(a.config, seeds[:1], a.workers)
        elif name == "jumpstart":
            E.run_jumpstart(a.config, seeds, a.workers, pre_rounds=5 if a.quick else 15)
        elif name == "beta":
            E.run_beta(a.config, seeds[:1], a.workers, iters=20 if a.quick else 100)
        elif name == "system":
            E.run_system(a.config, seeds)
        elif name == "scalability":
            E.run_scalability(a.config, a.workers, slots=120 if a.quick else 600, seeds=(0,) if a.quick else (0, 1, 2))
        elif name == "continual":
            E.run_continual(a.config, seeds, a.workers, n_enc=8 if a.quick else 32)
        elif name == "ablation":
            E.run_ablation(a.config, seeds[:1], a.workers, iters=20 if a.quick else 100)
        else:
            raise SystemExit(f"unknown experiment: {name}")
        print(f"--- {name} done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
'@

Write-ProjectFile 'scripts\screen_tle.py' @'
"""Screen a full Starlink TLE file down to the satellites used in the simulation (Sec. V-A).

Usage:
  python scripts/screen_tle.py --tle starlink_full.txt --start 2026-11-08T00:00:00 --out data/starlink_screened.txt
Download the full file from https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=tle
"""
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from satecn.orbits import load_tle, screen_tles  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tle", required=True)
    ap.add_argument("--start", default="2026-11-08T00:00:00")
    ap.add_argument("--window", type=int, default=600)
    ap.add_argument("--lat", type=float, default=42.3732)
    ap.add_argument("--lon", type=float, default=-72.5199)
    ap.add_argument("--target", type=int, default=18, help="desired number of screened satellites")
    ap.add_argument("--scan-minutes", type=int, default=120, help="search window starts over this span")
    ap.add_argument("--alt-min", type=float, default=440.0)
    ap.add_argument("--alt-max", type=float, default=600.0)
    ap.add_argument("--out", default="data/starlink_screened.txt")
    a = ap.parse_args()

    tles = load_tle(a.tle)
    t0 = datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc)
    best = None
    for m in range(0, a.scan_minutes, 10):
        start = t0 + timedelta(minutes=m)
        keep, el = screen_tles(tles, start, a.window, a.lat, a.lon, alt_range=(a.alt_min, a.alt_max))
        vis = (el >= 55).sum(axis=0).mean() if len(keep) else 0.0
        print(f"start={start.isoformat()} screened={len(keep)} mean_visible={vis:.2f}")
        score = abs(len(keep) - a.target)
        if best is None or score < best[0]:
            best = (score, start, keep, vis)
        if score == 0:
            break
    _, start, keep, vis = best
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for k in keep:
            f.write("\n".join(tles[k]) + "\n")
    print(f"wrote {len(keep)} satellites to {out} (window start {start.isoformat()}, mean visible {vis:.2f})")


if __name__ == "__main__":
    main()
'@

Write-ProjectFile 'src\satecn\__init__.py' @'
"""SATECN simulator and lifelong-learning agents (reproduction of Wu et al., IEEE TWC 2026)."""
'@

Write-ProjectFile 'src\satecn\channel.py' @'
"""Uplink rate models: IoT-UAV air-to-ground (Eqs. 8-9) and IoT-LEO (Eq. 10)."""
from __future__ import annotations

import numpy as np

C_LIGHT = 3.0e8


def _db2lin(x):
    return 10.0 ** (np.asarray(x) / 10.0)


def fspl_db(d_m, f_hz):
    return 20.0 * np.log10(np.maximum(d_m, 1.0)) + 20.0 * np.log10(f_hz) + 20.0 * np.log10(4 * np.pi / C_LIGHT)


def uav_path_loss_lin(iot_xy: np.ndarray, uav_xy: np.ndarray, cfg: dict) -> np.ndarray:
    """Average LoS/NLoS path loss L_{i,u}(t) of Eq. (8), linear scale, shape (N, U)."""
    h = cfg["altitude_m"]
    r = np.linalg.norm(iot_xy[:, None, :] - uav_xy[None, :, :], axis=-1)
    d = np.sqrt(r ** 2 + h ** 2)
    theta = np.degrees(np.arctan2(h, r))
    a, b = cfg["env_a"], cfg["env_b"]
    p_los = 1.0 / (1.0 + a * np.exp(-b * (theta - a)))
    base = fspl_db(d, cfg["carrier_hz"])
    pl_los = _db2lin(base + cfg["eta_los_db"])
    pl_nlos = _db2lin(base + cfg["eta_nlos_db"])
    return p_los * pl_los + (1.0 - p_los) * pl_nlos


def uav_rate(path_loss_lin: np.ndarray, power_w: np.ndarray, cfg: dict) -> np.ndarray:
    """Eq. (9): R = B log2(1 + P / (L N0 B)). power_w broadcasts against path_loss_lin."""
    B = cfg["bandwidth_hz"]
    n0 = _db2lin(cfg["noise_dbm_hz"] + cfg["noise_figure_db"]) * 1e-3  # W/Hz
    return B * np.log2(1.0 + power_w / (path_loss_lin * n0 * B))


def leo_gain(range_km: np.ndarray, cfg: dict, rng: np.random.Generator, n_iot: int) -> np.ndarray:
    """g_i * H_{i,l}(t) / N0 per watt for each (IoT, satellite), shape (N, L).

    Free-space loss over the slant range, antenna gains, and Rician small-scale fading.
    """
    pl = fspl_db(range_km * 1e3, cfg["carrier_hz"])
    g_db = cfg["iot_gain_dbi"] + cfg["sat_gain_dbi"] - pl
    k = cfg["rician_k"]
    L = range_km.shape[0]
    los = np.sqrt(k / (k + 1))
    sc = np.sqrt(1 / (2 * (k + 1)))
    h = los + sc * (rng.standard_normal((n_iot, L)) + 1j * rng.standard_normal((n_iot, L)))
    fading = np.abs(h) ** 2
    n0 = _db2lin(cfg["noise_dbm_hz"] + cfg["noise_figure_db"]) * 1e-3 * cfg["bandwidth_hz"]
    return _db2lin(g_db)[None, :] * fading / n0


def leo_rate(gain_per_w: np.ndarray, power_w, cfg: dict) -> np.ndarray:
    """Eq. (10): R = B log2(1 + P g H / N0)."""
    return cfg["bandwidth_hz"] * np.log2(1.0 + np.asarray(power_w) * gain_per_w)
'@

Write-ProjectFile 'src\satecn\config.py' @'
"""Config loading with project-root-relative paths."""
from __future__ import annotations

import copy
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]


def load_config(path: str | Path | None = None, overrides: dict | None = None) -> dict:
    path = Path(path) if path else ROOT / "configs" / "default.yaml"
    if not path.is_absolute() and not path.exists():
        path = ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"config not found: {path}")
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    for key, val in (overrides or {}).items():  # dotted keys, e.g. {"objective.beta": 0.5}
        node = cfg
        parts = key.split(".")
        for p in parts[:-1]:
            node = node[p]
        node[parts[-1]] = val
    return cfg


def clone(cfg: dict) -> dict:
    return copy.deepcopy(cfg)
'@

Write-ProjectFile 'src\satecn\domains.py' @'
"""RL domains of Table II and the RL-task descriptor Z_{i,t}^k of Eq. (17)."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

N_FEAT = 3  # policy features phi(x) = [1, AoI/norm, D_rem/norm]


@dataclass(frozen=True)
class DomainSpec:
    gid: int
    configs: tuple            # SAT configurations of Table I covered by this domain
    cats: tuple               # executor categories chosen by the softmax head
    cont: tuple               # continuous resource controls (Gaussian heads)
    n_iot: int
    n_uav: int
    use_leo: bool
    local: bool               # IoT local computing available
    assigned: bool = False    # domain 2: executor fixed per IoT, only power is learned

    @property
    def dim(self) -> int:
        n_logit = 0 if self.assigned else max(len(self.cats), 1) - 1
        return n_logit * N_FEAT + len(self.cont) * N_FEAT


# Table II. Domain 2 assigns 10 IoTs to the UAVs and 10 to the LEOs and learns power only.
DOMAINS = {
    1: DomainSpec(1, (1,), ("hold", "local"), ("eps",), 10, 0, False, True),
    2: DomainSpec(2, (2, 3), ("uav", "leo"), ("p_uav", "p_leo"), 20, 2, True, False, assigned=True),
    3: DomainSpec(3, (6,), ("uav", "leo"), (), 10, 2, True, False),
    4: DomainSpec(4, (6,), ("uav", "leo"), ("p",), 10, 2, True, False),
    5: DomainSpec(5, (4,), ("local", "uav"), ("eps", "eps_o", "p"), 10, 2, False, True),
    6: DomainSpec(6, (4, 5, 7), ("local", "uav", "leo"), ("eps", "eps_o", "p"), 10, 2, True, True),
}


@dataclass
class TaskSpec:
    """One RL task k: a domain plus sampled environment parameters (Eq. 17)."""
    kid: int
    gid: int
    lam: np.ndarray           # task arrival rate per IoT (tasks/slot)
    d_mean_mb: np.ndarray     # mean task size per IoT (MB)
    rho: np.ndarray           # processing density per IoT (cycles/bit)
    iot_xy: np.ndarray        # IoT positions (m)
    uav_xy0: np.ndarray       # initial UAV positions (m)
    leo_offset: int           # start offset (s) inside the LEO visibility window
    seed: int
    meta: dict = field(default_factory=dict)

    @property
    def domain(self) -> DomainSpec:
        return DOMAINS[self.gid]

    def descriptor(self) -> np.ndarray:
        """Compact descriptor used for task identification (isNewTask in Alg. 1)."""
        return np.array([self.gid, self.lam.mean(), self.d_mean_mb.mean(), self.rho.mean(), self.leo_offset])


def make_task(kid: int, gid: int, cfg: dict, rng: np.random.Generator, n_iot: int | None = None,
              n_uav: int | None = None) -> TaskSpec:
    """Sample one RL task. n_iot / n_uav override the domain defaults (scalability study, Table V)."""
    spec = DOMAINS[gid]
    n = n_iot or spec.n_iot
    U = spec.n_uav if n_uav is None else n_uav
    io = cfg["iot"]
    lam = rng.uniform(*io["lambda_range"], size=n) * io["lambda_scale"] * cfg["sim"]["slot_s"]
    d = np.maximum(rng.normal(io["task_mb_mean"], io["task_mb_std"], size=n), io["task_mb_min"])
    rho = rng.uniform(*io["rho_range"], size=n)
    size = cfg["area"]["size_m"]
    iot_xy = rng.uniform(0, size, size=(n, 2))
    uav_xy0 = rng.uniform(0, size, size=(max(U, 1), 2))
    off = int(rng.integers(0, cfg["leo"]["window_s"]))
    return TaskSpec(kid, gid, lam, d, rho, iot_xy, uav_xy0, off, int(rng.integers(1 << 30)), meta={"n_uav": U})


def make_task_set(cfg: dict, seed: int, per_domain: int, domains=(1, 2, 3, 4, 5, 6), start_kid: int = 1):
    """Tasks are numbered domain-major (tasks 1-4 domain 1, ..., 21-24 domain 6) as in Sec. V."""
    rng = np.random.default_rng(seed)
    tasks, kid = [], start_kid
    for g in domains:
        for _ in range(per_domain):
            tasks.append(make_task(kid, g, cfg, rng))
            kid += 1
    return tasks
'@

Write-ProjectFile 'src\satecn\environment.py' @'
"""Slotted SATECN simulator implementing the system model of Sec. II-III.

Per slot and per IoT: Poisson arrivals, FCFS dispatch to the executor chosen by the policy
(local CPU, UAV or LEO; no task splitting, Eq. 1), local/remote computation (Eqs. 2-4),
uplink transmission (Eqs. 5-6, 9-11), queue evolution (Eq. 12), AoI (Eqs. 13-14) and the
AoI-energy penalty (Eq. 15).
"""
from __future__ import annotations

from collections import deque

import numpy as np

from .channel import leo_gain, leo_rate, uav_path_loss_lin, uav_rate
from .domains import TaskSpec
from .orbits import LEOGeometry

HOLD, LOCAL, UAV, LEO = 0, 1, 2, 3
CAT_CODE = {"hold": HOLD, "local": LOCAL, "uav": UAV, "leo": LEO}
BITS_PER_MB = 8.0e6


class SATECNEnv:
    def __init__(self, cfg: dict, geom: LEOGeometry | None, task: TaskSpec, seed: int | None = None):
        self.cfg, self.geom, self.task = cfg, geom, task
        self.spec = task.domain
        self.n = len(task.lam)
        self.U = task.meta.get("n_uav", self.spec.n_uav)
        self.use_leo = self.spec.use_leo and geom is not None
        self.L = geom.n_sats if self.use_leo else 0
        self.dt = cfg["sim"]["slot_s"]
        self.rng = np.random.default_rng(task.seed if seed is None else seed)
        io, uv, lo = cfg["iot"], cfg["uav"], cfg["leo"]
        self.eps_max_i = io["eps_max"] * self.dt
        self.eps_max_u = uv["eps_max"] * self.dt
        self.eps_max_l = lo["eps_max"] * self.dt
        self.beta = cfg["objective"]["beta"]
        self.escale = cfg["objective"]["energy_scale"]
        # domain 2: first half of the IoTs is served by UAVs, second half by LEOs
        self.assign = np.where(np.arange(self.n) < self.n // 2, UAV, LEO) if self.spec.assigned else None

    # ------------------------------------------------------------------ episode
    def reset(self):
        n = self.n
        self.t = 0
        self.unbound = [deque() for _ in range(n)]       # [gen, bits]
        self.lpipe = [deque() for _ in range(n)]         # [gen, cycles_left]
        self.lback = np.zeros(n)                          # local backlog (cycles)
        self.txq = {UAV: [deque() for _ in range(n)], LEO: [deque() for _ in range(n)]}  # [gen, bits_left, cycles]
        self.txback = {UAV: np.zeros(n), LEO: np.zeros(n)}
        self.nodeq = {}                                   # (node, i) -> deque [gen, cycles_left]
        self.unbound_bits = np.zeros(n)
        self.aoi = np.zeros(n)
        self.uav_xy = self.task.uav_xy0[: max(self.U, 1)].copy()
        self.uav_wp = self.rng.uniform(0, self.cfg["area"]["size_m"], size=self.uav_xy.shape)
        self.uav_v = self.rng.uniform(*self.cfg["uav"]["speed_mps"], size=self.uav_xy.shape[0])
        self.stats = {k: 0.0 for k in ("gen", "done_iot", "done_uav", "done_leo", "e_local", "e_tx_uav",
                                       "e_tx_leo", "e_uav", "e_leo")}
        return self.state()

    def state(self) -> np.ndarray:
        """x_t = {AoI, D_rem} per IoT; D_rem in MB (Sec. IV-B)."""
        drem = self.unbound_bits + self.txback[UAV] + self.txback[LEO]
        drem = drem + self.lback / self.task.rho
        return np.stack([self.aoi, drem / BITS_PER_MB], axis=1)

    def critic_state(self) -> np.ndarray:
        """Extra per-IoT observables for the critic only (pipeline backlogs, MB). Not used by the policy."""
        node = np.zeros(self.n)
        for (nd, i), q in self.nodeq.items():
            node[i] += sum(it[1] for it in q) / self.task.rho[i]
        return np.stack([self.unbound_bits, self.lback / self.task.rho, self.txback[UAV], self.txback[LEO], node],
                        axis=1) / BITS_PER_MB

    def queue_lengths(self) -> dict:
        loc = sum(len(q) + len(p) for q, p in zip(self.unbound, self.lpipe))
        to_u = sum(len(q) for q in self.txq[UAV]) + sum(len(q) for (nd, _), q in self.nodeq.items() if nd < 100)
        to_l = sum(len(q) for q in self.txq[LEO]) + sum(len(q) for (nd, _), q in self.nodeq.items() if nd >= 100)
        return {"local": loc, "to_uav": to_u, "to_leo": to_l}

    # ------------------------------------------------------------------ helpers
    def _move_uavs(self):
        d = self.uav_wp - self.uav_xy
        dist = np.linalg.norm(d, axis=1)
        step = self.uav_v * self.dt
        arrive = dist <= step
        self.uav_xy = np.where(arrive[:, None], self.uav_wp, self.uav_xy + d / np.maximum(dist, 1e-9)[:, None] * step[:, None])
        if arrive.any():
            self.uav_wp[arrive] = self.rng.uniform(0, self.cfg["area"]["size_m"], size=(arrive.sum(), 2))

    @staticmethod
    def _serve(q: deque, budget: float, done_gens: list) -> float:
        """FCFS service of a queue whose entries hold remaining work at index 1. Returns work used."""
        used = 0.0
        while q and budget > 1e-9:
            item = q[0]
            w = min(item[1], budget)
            item[1] -= w
            budget -= w
            used += w
            if item[1] <= 1e-9:
                done_gens.append(q.popleft())
        return used

    # ------------------------------------------------------------------ step
    def step(self, act: dict):
        """Advance one slot. act: cat (n,) codes, eps/eps_o/p (n,) fractions in [0, 1]."""
        cfg, n, t, dt = self.cfg, self.n, self.t, self.dt
        io, uv, lo = cfg["iot"], cfg["uav"], cfg["leo"]
        rho = self.task.rho
        cat = act["cat"]
        eps = np.clip(act["eps"], 0, 1)
        eps_o = np.clip(act["eps_o"], 0, 1)
        pfr = np.clip(act["p"], 0, 1)
        energy = np.zeros(n)
        fresh = np.full(n, -np.inf)       # freshest generation time completed this slot

        # 1) arrivals (Poisson, sizes sampled around D_i)
        cnt = self.rng.poisson(self.task.lam)
        for i in np.nonzero(cnt)[0]:
            sizes = np.maximum(self.rng.normal(self.task.d_mean_mb[i], io["per_task_cv"] * self.task.d_mean_mb[i], cnt[i]), 0.05)
            for s in sizes * BITS_PER_MB:
                self.unbound[i].append([t, s])
                self.unbound_bits[i] += s
        self.stats["gen"] += cnt.sum()

        # 2) channels: best UAV / best visible LEO per IoT by instantaneous rate
        r_uav = np.zeros(n)
        r_leo = np.zeros(n)
        best_u = np.zeros(n, dtype=int)
        best_l = np.zeros(n, dtype=int)
        p_uav = io["p_max_uav"] * pfr
        p_leo = io["p_max_leo"] * pfr
        if self.U > 0:
            self._move_uavs()
            pl = uav_path_loss_lin(self.task.iot_xy, self.uav_xy[: self.U], uv)
            best_u = np.argmin(pl, axis=1)
            r_uav = uav_rate(pl[np.arange(n), best_u], p_uav, uv)
        if self.use_leo:
            tt = (t + self.task.leo_offset) % self.geom.window
            vis = self.geom.elev_deg[:, tt] >= self.geom.min_elev
            if vis.any():
                g = leo_gain(self.geom.range_km[:, tt], lo, self.rng, n)
                g[:, ~vis] = 0.0
                best_l = np.argmax(g, axis=1)
                r_leo = leo_rate(g[np.arange(n), best_l], p_leo, lo)
        rate = {UAV: r_uav, LEO: r_leo}
        ptx = {UAV: p_uav, LEO: p_leo}

        # 3) dispatch: bind head-of-line tasks to the chosen executor (no splitting)
        for i in range(n):
            c = cat[i]
            ub = self.unbound[i]
            if c == HOLD or not ub:
                continue
            if c == LOCAL:
                cap = eps[i] * self.eps_max_i
                while ub and self.lback[i] < cap:
                    g_, b = ub.popleft()
                    self.unbound_bits[i] -= b
                    self.lpipe[i].append([g_, b * rho[i]])
                    self.lback[i] += b * rho[i]
            else:
                cap = rate[c][i] * dt
                q = self.txq[c][i]
                while ub and self.txback[c][i] < cap:
                    g_, b = ub.popleft()
                    self.unbound_bits[i] -= b
                    q.append([g_, b, b * rho[i]])
                    self.txback[c][i] += b

        # 4) local computation, Eqs. (3)-(4): E = xi * alpha * cycles * f^2
        f_loc = eps * self.eps_max_i / dt
        for i in range(n):
            if self.lpipe[i]:
                done = []
                used = self._serve(self.lpipe[i], eps[i] * self.eps_max_i, done)
                self.lback[i] -= used
                e = io["xi_cpt"] * io["alpha"] * used * f_loc[i] ** 2
                energy[i] += e
                self.stats["e_local"] += e
                if done:
                    self.stats["done_iot"] += len(done)
                    fresh[i] = max(fresh[i], max(d[0] for d in done))

        # 5) remote computation at UAV / LEO nodes with admission scaling (16d)
        if self.nodeq:
            by_node = {}
            for (nd, i), q in self.nodeq.items():
                if q:
                    by_node.setdefault(nd, []).append(i)
            for nd, users in by_node.items():
                is_leo = nd >= 100
                cmax = self.eps_max_l if is_leo else self.eps_max_u
                alpha = lo["alpha"] if is_leo else uv["alpha"]
                xi = lo["xi_cpt"] if is_leo else uv["xi_cpt"]
                req = np.maximum(eps_o[users], 0.05) * cmax
                if req.sum() > cmax:
                    req *= cmax / req.sum()
                for i, alloc in zip(users, req):
                    done = []
                    used = self._serve(self.nodeq[(nd, i)], alloc, done)
                    e = xi * alpha * used * (alloc / dt) ** 2
                    energy[i] += e
                    self.stats["e_leo" if is_leo else "e_uav"] += e
                    if done:
                        self.stats["done_leo" if is_leo else "done_uav"] += len(done)
                        fresh[i] = max(fresh[i], max(d[0] for d in done))

        # 6) uplink transmission, Eqs. (5)-(6), (11); single radio per IoT
        for i in range(n):
            c = cat[i]
            if c in (UAV, LEO) and self.txback[c][i] > 0:
                link = c
            elif self.txback[UAV][i] > 0:
                link = UAV
            elif self.txback[LEO][i] > 0:
                link = LEO
            else:
                continue
            r = rate[link][i]
            if r <= 0:
                continue
            q = self.txq[link][i]
            sent, budget = 0.0, r * dt
            node = (int(best_u[i]) if link == UAV else 100 + int(best_l[i]), i)
            while q and budget > 1e-9:
                item = q[0]
                w = min(item[1], budget)
                item[1] -= w
                budget -= w
                sent += w
                if item[1] <= 1e-9:
                    q.popleft()
                    self.nodeq.setdefault(node, deque()).append([item[0], item[2]])
            self.txback[link][i] -= sent
            e = io["xi_tr"] * ptx[link][i] * sent / r
            energy[i] += e
            self.stats["e_tx_uav" if link == UAV else "e_tx_leo"] += e

        # 7) AoI, Eq. (14): +1 if nothing completes, otherwise age of the freshest completed task
        upd = np.isfinite(fresh)
        self.aoi = np.where(upd, np.minimum(self.aoi + 1, t + 1 - np.where(upd, fresh, 0)), self.aoi + 1)
        self.t += 1

        # 8) penalty, Eq. (15)
        cost = self.beta * self.aoi + self.escale * (1 - self.beta) * energy
        return self.state(), cost, energy
'@

Write-ProjectFile 'src\satecn\exhaustive.py' @'
"""Exhaustive-search baseline: brute force over a discretised grid of stationary decisions.

Each grid point fixes the executor-selection probabilities and the normalised resource levels
(CPU share, remote CPU share, transmit power); every point is simulated and the best is kept.
"""
from __future__ import annotations

import itertools

import numpy as np

from .domains import DOMAINS, N_FEAT
from .learners import rollout
from .policy import LinearPolicy


def simplex_grid(k: int, step: float):
    m = int(round(1 / step))
    for c in itertools.product(range(m + 1), repeat=k):
        if sum(c) == m:
            yield np.array(c) / m


def grid_theta(gid: int, probs, cont_vals) -> np.ndarray:
    spec = DOMAINS[gid]
    th = []
    if len(spec.cats) > 1 and not spec.assigned:
        p = np.maximum(np.asarray(probs), 1e-6)
        for j in range(1, len(spec.cats)):
            th += [np.log(p[j] / p[0]), 0.0, 0.0]
    for v in cont_vals:
        v = min(max(v, 1e-3), 1 - 1e-3)
        th += [np.log(v / (1 - v)), 0.0, 0.0]          # logit-normal head: sigmoid(theta . phi) = v
    return np.array(th)


def exhaustive_search(cfg, geom, task, prob_step=0.25, levels=(0.25, 0.5, 0.75, 1.0), n_episodes=2, seed=0):
    spec = DOMAINS[task.gid]
    pol = LinearPolicy(spec, sigma=1e-9)
    ncat = len(spec.cats) if not spec.assigned else 1
    prob_set = list(simplex_grid(ncat, prob_step)) if ncat > 1 else [np.ones(1)]
    best = None
    results = []
    for probs in prob_set:
        for vals in itertools.product(levels, repeat=len(spec.cont)):
            th = grid_theta(task.gid, probs, vals)
            m = rollout(cfg, geom, task, pol, th, np.random.default_rng(seed), n_episodes=n_episodes)["metrics"]
            results.append((m["penalty"], probs.tolist(), list(vals)))
            if best is None or m["penalty"] < best[0]["penalty"]:
                best = (m, th, probs.tolist(), list(vals))
    return {"metrics": best[0], "theta": best[1], "probs": best[2], "levels": best[3], "n_evaluated": len(results)}
'@

Write-ProjectFile 'src\satecn\experiments.py' @'
"""Experiment drivers reproducing Sec. V (Figs. 3-9, Table V) plus ablations.

Every experiment writes JSON into experiments/results; figures are produced by scripts/make_figures.py.
"""
from __future__ import annotations

import json
import pickle
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np

from .config import ROOT, load_config
from .domains import DOMAINS, make_task, make_task_set
from .exhaustive import exhaustive_search
from .orbits import build_geometry
from .trainer import ALGOS, Agent, train_stream

RES = ROOT / "experiments" / "results"
CKPT = ROOT / "experiments" / "checkpoints"


def _save(name: str, obj):
    RES.mkdir(parents=True, exist_ok=True)
    with open(RES / f"{name}.json", "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, default=lambda o: o.tolist() if isinstance(o, np.ndarray) else float(o))
    print(f"[saved] {RES / (name + '.json')}", flush=True)


def _load(name: str):
    with open(RES / f"{name}.json", encoding="utf-8") as f:
        return json.load(f)


def base_tasks(cfg, seed):
    return make_task_set(cfg, seed=1000 + seed, per_domain=cfg["tasks"]["per_domain"])


def new_tasks_domain6(cfg, seed):
    rng = np.random.default_rng(5000 + seed)
    n0 = 6 * cfg["tasks"]["per_domain"] + 1
    return [make_task(n0 + j, 6, cfg, rng) for j in range(cfg["tasks"]["new_domain6"])]


# ----------------------------------------------------------------------------- main (Figs. 3, 4, 7)
def _main_job(args):
    algo, seed, cfg_path, iters = args
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    tasks = base_tasks(cfg, seed)
    agent = Agent(algo, cfg, seed=10 * seed + ALGOS.index(algo))
    t0 = time.time()
    hist = train_stream(agent, tasks, geom, iters, log_every=20, tag=f"s{seed} ")
    wall = time.time() - t0
    CKPT.mkdir(parents=True, exist_ok=True)
    with open(CKPT / f"{algo}_seed{seed}.pkl", "wb") as f:
        pickle.dump(agent, f)
    extra = {"recon_error": agent.kb.recon_error(), "kb_params": agent.kb.n_params()} if agent.kb else {}
    return algo, seed, {str(k): v for k, v in hist.items()}, {t.kid: t.gid for t in tasks}, wall, extra


def run_main(cfg_path, seeds, iters, workers):
    jobs = [(a, s, cfg_path, iters) for s in seeds for a in ALGOS]
    with Pool(workers) as pool:
        out = pool.map(_main_job, jobs)
    res = {"iterations": iters, "seeds": list(seeds), "algos": list(ALGOS), "runs": {}}
    for algo, seed, hist, kid2g, wall, extra in out:
        res["runs"][f"{algo}|{seed}"] = {"hist": hist, "wall_s": wall, **extra}
        res["task_domain"] = {str(k): g for k, g in kid2g.items()}
    _save("main", res)


# ----------------------------------------------------------------------------- exhaustive (Fig. 3 line)
def _exh_job(args):
    cfg_path, seed, kid = args
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    task = [t for t in base_tasks(cfg, seed) if t.kid == kid][0]
    r = exhaustive_search(cfg, geom, task, n_episodes=1, seed=seed)
    from .learners import rollout
    from .policy import LinearPolicy
    m = rollout(cfg, geom, task, LinearPolicy(task.domain, 1e-9), r["theta"], np.random.default_rng(77), 3)["metrics"]
    return seed, kid, {"grid_best": r["metrics"]["penalty"], "eval": m, "probs": r["probs"], "levels": r["levels"],
                       "n_evaluated": r["n_evaluated"]}


def run_exhaustive(cfg_path, seeds, workers, domain=6):
    cfg = load_config(cfg_path)
    kids = [t.kid for t in base_tasks(cfg, 0) if t.gid == domain]
    jobs = [(cfg_path, s, k) for s in seeds for k in kids]
    with Pool(workers) as pool:
        out = pool.map(_exh_job, jobs)
    _save("exhaustive", {"domain": domain, "runs": {f"{s}|{k}": r for s, k, r in out}})


# ----------------------------------------------------------------------------- jumpstart (Fig. 6)
def _jump_job(args):
    cfg_path, seed, pre_rounds, n_eval, n_inits = args
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    tasks = base_tasks(cfg, seed)
    rng = np.random.default_rng(9000 + seed)
    held = [make_task(200 + g, g, cfg, rng) for g in DOMAINS]           # one unseen task per domain
    out = {}
    for algo in ("msr_nac_cdll", "msr_nac_ella"):
        ag = Agent(algo, cfg, seed=100 + seed)
        train_stream(ag, tasks, geom, pre_rounds, log_every=0)
        out[algo] = {}
        for t in held:
            ag.ensure_task(t)
            out[algo][t.gid] = ag.evaluate(t, geom, n_episodes=n_eval, seed=seed)["penalty"]
    out["msr_nac"] = {}
    for t in held:                                                       # learning from scratch: random init
        vals = []
        for j in range(n_inits):
            ag = Agent("msr_nac", cfg, seed=300 + 17 * seed + j)
            vals.append(ag.evaluate(t, geom, n_episodes=n_eval, seed=seed)["penalty"])
        out["msr_nac"][t.gid] = float(np.mean(vals))
    return seed, out


def run_jumpstart(cfg_path, seeds, workers, pre_rounds=15, n_eval=3, n_inits=5):
    jobs = [(cfg_path, s, pre_rounds, n_eval, n_inits) for s in seeds]
    with Pool(workers) as pool:
        out = pool.map(_jump_job, jobs)
    _save("jumpstart", {"pre_rounds": pre_rounds, "runs": {str(s): r for s, r in out}})


# ----------------------------------------------------------------------------- beta sweep (Fig. 5)
def _beta_job(args):
    cfg_path, beta, seed, iters = args
    cfg = load_config(cfg_path, overrides={"objective.beta": beta})
    geom = build_geometry(cfg, ROOT)
    tasks = [t for t in base_tasks(cfg, seed) if t.gid == 6]
    ag = Agent("msr_nac_cdll", cfg, seed=400 + seed)
    train_stream(ag, tasks, geom, iters, log_every=0)
    ms = [ag.evaluate(t, geom, n_episodes=3, seed=seed) for t in tasks]
    return beta, seed, {k: float(np.mean([m[k] for m in ms])) for k in ("penalty", "aoi", "energy")}


def run_beta(cfg_path, seeds, workers, betas=(0.0, 0.2, 0.4, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0), iters=100):
    jobs = [(cfg_path, b, s, iters) for b in betas for s in seeds]
    with Pool(workers) as pool:
        out = pool.map(_beta_job, jobs)
    res = {"iterations": iters, "betas": list(betas), "runs": {}}
    for b, s, m in out:
        res["runs"][f"{b}|{s}"] = m
    _save("beta_sweep", res)


# ----------------------------------------------------------------------------- system analysis (Fig. 8)
def run_system(cfg_path, seeds, n_eval=5):
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    res = {}
    for seed in seeds:
        with open(CKPT / f"msr_nac_cdll_seed{seed}.pkl", "rb") as f:
            ag = pickle.load(f)
        for t in base_tasks(cfg, seed):
            m = ag.evaluate(t, geom, n_episodes=n_eval, seed=seed)
            res[f"{seed}|{t.kid}"] = {"gid": t.gid, **m}
    _save("system", res)


# ----------------------------------------------------------------------------- scalability (Table V)
CTRL = {"status_bytes": 32, "policy_bytes_per_param": 4, "seg_report_bytes": 64, "hap_km": 20.0,
        "backhaul_bps": 1.0e8, "proc_s": 1.0e-4}


def _scal_job(args):
    cfg_path, N, seed, slots = args
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    with open(CKPT / "msr_nac_cdll_seed0.pkl", "rb") as f:
        ag = pickle.load(f)
    rng = np.random.default_rng(7000 + seed)
    task = make_task(900 + N, 6, cfg, rng, n_iot=N, n_uav=N // 5)
    ref = [k for k, t in ag.kb.tasks.items() if t["g"] == 6]
    theta = np.mean([ag.kb.theta(k) for k in ref], axis=0)              # domain-6 policy, size independent of N
    from .environment import SATECNEnv
    from .policy import LinearPolicy, features
    pol = LinearPolicy(DOMAINS[6], cfg["policy"]["sigma"])
    env = SATECNEnv(cfg, geom, task, seed=seed)
    s = env.reset()
    aoi, en, t0 = [], 0.0, time.time()
    for _ in range(slots):
        act, _ = pol.act(theta, features(s, cfg), rng)
        s, c, e = env.step(act)
        aoi.append(s[:, 0].mean())
        en += e.sum()
    sim_wall = time.time() - t0
    # control-plane accounting (modelled): per-slot status upload from every IoT, per-slot segment report
    # from each local SDNC to the SAT-SDNC on the HAP, and one policy dissemination per learning round.
    st = env.stats
    tx_e = st["e_tx_uav"] + st["e_tx_leo"]
    p_up = cfg["iot"]["p_max_uav"]
    r_ctrl = 1.0e6                                                     # control uplink on the 1 MHz IoT channel
    ctrl_bits = slots * N * CTRL["status_bytes"] * 8 + (slots // cfg["sim"]["episode_slots"] + 1) * N * \
        DOMAINS[6].dim * CTRL["policy_bytes_per_param"] * 8
    ctrl_e = ctrl_bits / r_ctrl * p_up
    seg_bits = CTRL["seg_report_bytes"] * 8 * (1 + N / 10)
    lat_ms = 1e3 * (seg_bits / CTRL["backhaul_bps"] + CTRL["hap_km"] * 1e3 / 3e8 + CTRL["proc_s"])
    total_e = en * cfg["objective"]["energy_scale"]
    return N, seed, {"aoi": float(np.mean(aoi)), "total_energy": float(total_e / slots),
                     "energy_per_iot": float(total_e / slots / N), "ctrl_energy_ratio": float(ctrl_e / max(tx_e, 1e-9)),
                     "ctrl_latency_ms": float(lat_ms), "sim_wall_s": sim_wall}


def run_scalability(cfg_path, workers, Ns=(80, 120, 160, 200, 240, 280), seeds=(0, 1, 2), slots=600):
    jobs = [(cfg_path, N, s, slots) for N in Ns for s in seeds]
    with Pool(workers) as pool:
        out = pool.map(_scal_job, jobs)
    _save("scalability", {"slots": slots, "ctrl_model": CTRL, "runs": {f"{N}|{s}": r for N, s, r in out}})


# ----------------------------------------------------------------------------- continual learning (Fig. 9)
def _cont_job(args):
    cfg_path, algo, seed, n_enc = args
    cfg = load_config(cfg_path)
    geom = build_geometry(cfg, ROOT)
    olds = base_tasks(cfg, seed)
    news = new_tasks_domain6(cfg, seed)
    p = CKPT / f"{algo}_seed{seed}.pkl"
    with open(p, "rb") as f:
        ag = pickle.load(f)                                              # pre-trained on tasks 1-24
    old_before = {t.kid: ag.evaluate(t, geom, n_episodes=2, seed=seed)["penalty"] for t in olds}
    rng = np.random.default_rng(6000 + seed)
    order = np.concatenate([rng.permutation(len(news)) for _ in range(n_enc // len(news))])
    seen, seq = set(), []
    for idx in order:
        t = news[idx]
        first = t.kid not in seen
        seen.add(t.kid)
        m = ag.train_step(t, geom)
        seq.append({"kid": t.kid, "first": first, "penalty": m["penalty"]})
    if ag.kb is not None:
        ag.kb.refit_all()
    old_after = {t.kid: ag.evaluate(t, geom, n_episodes=2, seed=seed)["penalty"] for t in olds}
    return algo, seed, {"seq": seq, "old_before": old_before, "old_after": old_after}


def run_continual(cfg_path, seeds, workers, n_enc=32):
    jobs = [(cfg_path, a, s, n_enc) for s in seeds for a in ALGOS]
    with Pool(workers) as pool:
        out = pool.map(_cont_job, jobs)
    _save("continual", {"runs": {f"{a}|{s}": r for a, s, r in out}})


# ----------------------------------------------------------------------------- ablations
def _abl_job(args):
    cfg_path, name, ov, algo, seed, iters = args
    doms = (5, 6) if algo == "msr_nac" else tuple(DOMAINS)              # CDLL variants need all domains
    cfg = load_config(cfg_path, overrides=ov)
    geom = build_geometry(cfg, ROOT)
    tasks = [t for t in base_tasks(cfg, seed) if t.gid in doms]
    ag = Agent(algo, cfg, seed=500 + seed)
    h = train_stream(ag, tasks, geom, iters, log_every=0)
    curve = np.mean([h[t.kid]["penalty"] for t in tasks], axis=0)
    return name, seed, {"curve": curve.tolist(), "mean": float(curve.mean()), "final": float(curve[-10:].mean())}


ABLATIONS = {
    "n_step=1": ({"learner.n_step": 1}, "msr_nac"),
    "n_step=10": ({"learner.n_step": 10}, "msr_nac"),
    "n_step=40 (default)": ({}, "msr_nac"),
    "n_step=120 (MC)": ({"learner.n_step": 120}, "msr_nac"),
    "CDLL h=4": ({"lifelong.h": 4}, "msr_nac_cdll"),
    "CDLL h=8 (default)": ({}, "msr_nac_cdll"),
    "CDLL h=15": ({"lifelong.h": 15}, "msr_nac_cdll"),
    "CDLL s_k=rand (Alg.1)": ({"lifelong.warm_start": False}, "msr_nac_cdll"),
    "CDLL no refit": ({"lifelong.refit_all": False}, "msr_nac_cdll"),
}


def run_ablation(cfg_path, seeds, workers, iters=100):
    jobs = [(cfg_path, n, ov, a, s, iters) for n, (ov, a) in ABLATIONS.items() for s in seeds]
    with Pool(workers) as pool:
        out = pool.map(_abl_job, jobs)
    _save("ablation", {"iterations": iters, "runs": {f"{n}|{s}": r for n, s, r in out}})
'@

Write-ProjectFile 'src\satecn\learners.py' @'
"""Single-task policy-gradient learners: episodic NAC [39] and the multi-step-return MSR-NAC.

Both return a natural-gradient direction w (penalty is minimised, so theta <- theta - step * w)
and the Fisher information F; a scaled F serves as the Hessian H_k in Eqs. (22)-(25).
"""
from __future__ import annotations

import numpy as np

from .environment import SATECNEnv
from .policy import LinearPolicy, features


def rollout(cfg, geom, task, policy: LinearPolicy, theta, rng, n_episodes=1, greedy=False, slots=None):
    """Run episodes with all IoTs of the task sharing policy theta.

    Returns arrays phi (E,T,n,3), grad (E,T,n,d), cost (E,T,n) and summary metrics.
    """
    T = slots or cfg["sim"]["episode_slots"]
    PHI, G, C, AOI, EN, ST, XC = [], [], [], [], [], [], []
    for _ in range(n_episodes):
        env = SATECNEnv(cfg, geom, task, seed=int(rng.integers(1 << 31)))
        s = env.reset()
        phis, grads, costs, aois, ens, xcs = [], [], [], [], [], []
        for _t in range(T):
            phi = features(s, cfg)
            xcs.append(env.critic_state())
            act, g = policy.act(theta, phi, rng, assign=env.assign, greedy=greedy)
            s, c, e = env.step(act)
            phis.append(phi); grads.append(g); costs.append(c); aois.append(s[:, 0]); ens.append(e)
        PHI.append(phis); G.append(grads); C.append(costs); AOI.append(aois); EN.append(ens); XC.append(xcs)
        st = dict(env.stats)
        st.update(env.queue_lengths())
        ST.append(st)
    PHI, G, C = np.asarray(PHI), np.asarray(G), np.asarray(C)
    escale = cfg["objective"]["energy_scale"]
    metrics = {
        "penalty": float(C.mean()),
        "aoi": float(np.mean(AOI)),
        "energy": float(escale * np.mean(EN)),
        "stats": {k: float(np.mean([s[k] for s in ST])) for k in ST[0]},
    }
    return {"phi": PHI, "grad": G, "cost": C, "xc": np.asarray(XC), "metrics": metrics}


def fisher(grad: np.ndarray) -> np.ndarray:
    """Per-step Fisher information F = E[grad log pi grad log pi^T]."""
    g = grad.reshape(-1, grad.shape[-1])
    return g.T @ g / len(g)


def hessian_from_fisher(F: np.ndarray, reg: float) -> np.ndarray:
    """H_k for Eqs. (22)-(25): Fisher scaled to unit mean eigenvalue (keeps KB steps well scaled)."""
    Fn = F / max(np.trace(F) / F.shape[0], 1e-12)
    return Fn + reg * np.eye(F.shape[0])


def _ridge_solve(X, y, ridge):
    A = X.T @ X + ridge * len(X) * np.eye(X.shape[1])
    return np.linalg.solve(A, X.T @ y)


def nac_episodic(batch, gamma: float, ridge: float):
    """Episodic NAC (Peters & Schaal 2008): regress R(tau) on [sum_t gamma^t grad log pi, 1]."""
    G, C = batch["grad"], batch["cost"]              # (E,T,n,d), (E,T,n)
    E, T, n, d = G.shape
    disc = gamma ** np.arange(T)
    psi = np.einsum("t,etnd->end", disc, G).reshape(E * n, d)
    R = np.einsum("t,etn->en", disc, C).reshape(E * n) / T
    X = np.hstack([psi, np.ones((E * n, 1))])
    sol = _ridge_solve(X, R, ridge)
    return sol[:d], fisher(G)


def _critic_feats(phi, xc=None, drem_norm=20.0):
    """Critic features: quadratic in (AoI, D_rem), remaining-horizon terms (finite window) and,
    when available, per-pipeline backlogs (critic-only information; the actor still sees x = {AoI, D_rem})."""
    a, d = phi[..., 1], phi[..., 2]
    T = phi.shape[1]
    tau = np.broadcast_to((1.0 - np.arange(T) / T)[None, :, None], a.shape)
    f = [np.ones_like(a), a, d, a * a, d * d, a * d, tau, tau * tau, tau * a, tau * d]
    if xc is not None:
        q = np.clip(xc / drem_norm, 0, 5)
        for j in range(q.shape[-1]):
            f += [q[..., j], tau * q[..., j]]
    return np.stack(f, axis=-1)


def msr_nac(batch, gamma: float, n_step: int, ridge: float):
    """MSR-NAC: NAC with compatible function approximation fitted to n-step returns.

    G_t^(n) = sum_{j<n} gamma^j c_{t+j} + gamma^n V(x_{t+n});  G_t^(n) - V(x_t) ~ grad log pi_t . w
    """
    PHI, G, C = batch["phi"], batch["grad"], batch["cost"]
    E, T, n, d = G.shape
    # critic V fitted to Monte-Carlo returns-to-go (truncated at the window end)
    mc = np.zeros_like(C)
    acc = np.zeros((E, n))
    for t in range(T - 1, -1, -1):
        acc = C[:, t] + gamma * acc
        mc[:, t] = acc
    Fc = _critic_feats(PHI, batch.get("xc"))
    v = _ridge_solve(Fc.reshape(-1, Fc.shape[-1]), mc.reshape(-1), ridge)
    V = Fc @ v                                         # (E,T,n)
    # n-step returns with bootstrap
    Gn = np.zeros_like(C)
    for t in range(T):
        end = min(t + n_step, T)
        disc = gamma ** np.arange(end - t)
        Gn[:, t] = np.einsum("k,ekn->en", disc, C[:, t:end])
        if end < T:
            Gn[:, t] += gamma ** (end - t) * V[:, end]
    adv = (Gn - V).reshape(-1)
    w = _ridge_solve(G.reshape(-1, d), adv, ridge)
    return w, fisher(G)


def natural_step(theta, w, F, step):
    """theta <- theta - step * w / sqrt(w^T F w): a fixed-KL natural-gradient step (penalty minimisation)."""
    q = float(w @ F @ w)
    return theta - step * w / np.sqrt(max(q, 1e-12))
'@

Write-ProjectFile 'src\satecn\lifelong.py' @'
"""Knowledge bases for lifelong policy-gradient learning.

CDLL (Sec. IV-C, Alg. 1):   theta_k = Psi_g L s_k, shared L (d_base x h), projection Psi_g (d_g x d_base),
                             updated with Eqs. (23)-(24); s_k from the Lasso of Eq. (25).
ELLA baseline (PG-ELLA):     theta_k = L_g s_k with a separate L_g per domain (no cross-domain sharing).
"""
from __future__ import annotations

import numpy as np


def lasso_quadratic(Q: np.ndarray, b: np.ndarray, mu1: float, s0: np.ndarray, iters: int = 100, tol=1e-6):
    """Coordinate descent for  min_s  s^T Q s - 2 b^T s + mu1 ||s||_1  (Q symmetric PSD)."""
    s = s0.copy()
    diag = np.maximum(np.diag(Q), 1e-12)
    for _ in range(iters):
        delta = 0.0
        for j in range(len(s)):
            r = b[j] - Q[j] @ s + Q[j, j] * s[j]
            new = np.sign(r) * max(abs(r) - mu1 / 2.0, 0.0) / diag[j]
            delta = max(delta, abs(new - s[j]))
            s[j] = new
        if delta < tol:
            break
    return s


class KnowledgeBase:
    def __init__(self, domain_dims: dict, lcfg: dict, rng: np.random.Generator, cross_domain: bool = True):
        self.cross = cross_domain
        self.h = lcfg["h"]
        self.eta_L, self.eta_psi = lcfg["eta_L"], lcfg["eta_psi"]
        self.mu1, self.mu2, self.mu3 = lcfg["mu1"], lcfg["mu2"], lcfg["mu3"]
        self.steps = lcfg["kb_steps"]
        self.warm = lcfg.get("warm_start", True)
        self.refit = lcfg.get("refit_all", True)
        self.rng = rng
        self.dims = dict(domain_dims)
        self.d_base = lcfg["d_base"]
        self.Psi: dict[int, np.ndarray] = {}
        self.Lg: dict[int, np.ndarray] = {}
        if self.cross:
            self.L = rng.normal(0, 1 / np.sqrt(self.h), (self.d_base, self.h))
        self.tasks: dict[int, dict] = {}   # kid -> {g, s, theta_hat, H}

    # ----------------------------------------------------------------- structure
    def _L(self, g):
        return self.L if self.cross else self.Lg[g]

    def _Psi(self, g):
        return self.Psi[g] if self.cross else None

    def basis(self, g) -> np.ndarray:
        """M_g = Psi_g L (CDLL) or L_g (ELLA), shape (d_g, h)."""
        return self.Psi[g] @ self.L if self.cross else self.Lg[g]

    def is_new_domain(self, g) -> bool:
        return (g not in self.Psi) if self.cross else (g not in self.Lg)

    def add_task(self, kid: int, g: int):
        """Alg. 1 lines 3-11: new task (and new domain if needed)."""
        if self.is_new_domain(g):
            d = self.dims[g]
            if self.cross:
                self.Psi[g] = self.rng.normal(0, 1 / np.sqrt(self.d_base), (d, self.d_base))
            else:
                self.Lg[g] = self.rng.normal(0, 1 / np.sqrt(self.h), (d, self.h))
        same = [t["s"] for t in self.tasks.values() if t["g"] == g]
        if self.warm and same:
            s = np.mean(same, axis=0)                # warm start from same-domain tasks
        elif self.warm and self.tasks and self.cross:
            s = np.mean([t["s"] for t in self.tasks.values()], axis=0)
        else:
            s = self.rng.random(self.h)               # Alg. 1 line 6: s_k <- rand
        self.tasks[kid] = {"g": g, "s": s, "theta_hat": None, "H": None}

    def theta(self, kid: int) -> np.ndarray:
        t = self.tasks[kid]
        return self.basis(t["g"]) @ t["s"]

    # ----------------------------------------------------------------- updates
    def _grad_L(self, only_g=None):
        """Gradient of Eq. (22) w.r.t. L (Eq. 23) and its Lipschitz bound (for a stable step)."""
        grad = self.mu3 * (self.L if self.cross else self.Lg[only_g])
        lip = self.mu3
        groups = {}
        for t in self.tasks.values():
            if t["theta_hat"] is None or (not self.cross and t["g"] != only_g):
                continue
            groups.setdefault(t["g"], []).append(t)
        for g, ts in groups.items():
            acc, lg = 0.0, 0.0
            for t in ts:
                s, H, th = t["s"], t["H"], t["theta_hat"]
                hn = np.linalg.norm(H, 2) * float(s @ s)
                if self.cross:
                    P = self.Psi[g]
                    acc = acc + (-P.T @ H @ np.outer(th, s) + P.T @ H @ P @ self.L @ np.outer(s, s))  # Eq. (23)
                    lg += hn * np.linalg.norm(P, 2) ** 2
                else:
                    acc = acc + (-H @ np.outer(th, s) + H @ self.Lg[g] @ np.outer(s, s))
                    lg += hn
            grad = grad + acc / len(ts)
            lip += lg / len(ts)
        return grad, lip

    def _grad_Psi(self, g):
        """Gradient of Eq. (22) w.r.t. Psi_g (Eq. 24) and its Lipschitz bound."""
        ts = [t for t in self.tasks.values() if t["g"] == g and t["theta_hat"] is not None]
        grad = self.mu2 * self.Psi[g]
        lip = self.mu2
        if ts:
            acc, lg = 0.0, 0.0
            for t in ts:
                Ls = self.L @ t["s"]
                acc = acc + (-t["H"] @ np.outer(t["theta_hat"], Ls) + t["H"] @ self.Psi[g] @ np.outer(Ls, Ls))  # Eq. (24)
                lg += np.linalg.norm(t["H"], 2) * float(Ls @ Ls)
            grad = grad + acc / len(ts)
            lip += lg / len(ts)
        return grad, lip

    def update(self, kid: int, theta_hat: np.ndarray, H: np.ndarray):
        """Alg. 1 lines 15-17: update L, Psi_g, then s_k (Lasso)."""
        t = self.tasks[kid]
        t["theta_hat"], t["H"] = theta_hat.copy(), H.copy()
        g = t["g"]
        # eta_L / eta_psi are relative step sizes, scaled by 1/Lipschitz so the bilinear updates stay stable
        for _ in range(self.steps):
            if self.cross:
                gL, lip = self._grad_L()
                self.L -= self.eta_L / lip * gL
                gP, lip = self._grad_Psi(g)
                self.Psi[g] -= self.eta_psi / lip * gP
            else:
                gL, lip = self._grad_L(only_g=g)
                self.Lg[g] -= self.eta_L / lip * gL
        if self.refit:
            self.refit_all()                                                  # keep stored policies consistent
        else:
            M = self.basis(g)
            t["s"] = lasso_quadratic(M.T @ H @ M, M.T @ H @ theta_hat, self.mu1, t["s"])  # Eq. (25)

    def refit_all(self):
        """Re-solve Eq. (25) for every stored task against the current basis, so a change of the
        shared L does not silently move the reconstructed policies of tasks not visited this round."""
        for t in self.tasks.values():
            if t["theta_hat"] is not None:
                M = self.basis(t["g"])
                t["s"] = lasso_quadratic(M.T @ t["H"] @ M, M.T @ t["H"] @ t["theta_hat"], self.mu1, t["s"])

    def recon_error(self) -> float:
        errs = [np.linalg.norm(self.theta(k) - t["theta_hat"]) / max(np.linalg.norm(t["theta_hat"]), 1e-9)
                for k, t in self.tasks.items() if t["theta_hat"] is not None]
        return float(np.mean(errs)) if errs else float("nan")

    def n_params(self) -> int:
        n = sum(t["s"].size for t in self.tasks.values())
        if self.cross:
            return n + self.L.size + sum(P.size for P in self.Psi.values())
        return n + sum(L.size for L in self.Lg.values())
'@

Write-ProjectFile 'src\satecn\orbits.py' @'
"""LEO geometry: Starlink TLE propagation (sgp4) with a synthetic-orbit fallback.

Provides per-second elevation and slant range of each screened satellite over the IoT area.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

R_EARTH_KM = 6378.137
MU_EARTH = 398600.4418  # km^3/s^2


def load_tle(path: str | Path) -> list[tuple[str, str, str]]:
    """Read a 3-line TLE file into (name, line1, line2) tuples."""
    lines = [l.rstrip() for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]
    out, i = [], 0
    while i + 2 < len(lines):
        if lines[i + 1].startswith("1 ") and lines[i + 2].startswith("2 "):
            out.append((lines[i].strip(), lines[i + 1], lines[i + 2]))
            i += 3
        else:
            i += 1
    if not out:
        raise ValueError(f"no valid TLE triplets found in {path}")
    return out


def _jd(dt: datetime) -> tuple[float, float]:
    """Julian date split into (whole, fraction) as expected by sgp4."""
    from sgp4.api import jday
    return jday(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second + dt.microsecond * 1e-6)


def _gmst_rad(jd_full: np.ndarray) -> np.ndarray:
    d = jd_full - 2451545.0
    return np.deg2rad((280.46061837 + 360.98564736629 * d) % 360.0)


def _ground_ecef(lat_deg: float, lon_deg: float, alt_km: float = 0.0) -> np.ndarray:
    lat, lon = math.radians(lat_deg), math.radians(lon_deg)
    r = R_EARTH_KM + alt_km
    return np.array([r * math.cos(lat) * math.cos(lon), r * math.cos(lat) * math.sin(lon), r * math.sin(lat)])


def _elev_range(sat_ecef: np.ndarray, lat_deg: float, lon_deg: float) -> tuple[np.ndarray, np.ndarray]:
    """Elevation (deg) and slant range (km) for positions shaped (..., 3)."""
    gs = _ground_ecef(lat_deg, lon_deg)
    up = gs / np.linalg.norm(gs)
    rel = sat_ecef - gs
    rng = np.linalg.norm(rel, axis=-1)
    sin_el = np.clip((rel @ up) / np.maximum(rng, 1e-9), -1.0, 1.0)
    return np.degrees(np.arcsin(sin_el)), rng


def propagate_tle(tles, start: datetime, n_seconds: int):
    """Propagate TLEs with sgp4; return ECEF positions (S, T, 3) km and altitudes (S,)."""
    from sgp4.api import Satrec, SatrecArray
    sats = SatrecArray([Satrec.twoline2rv(l1, l2) for _, l1, l2 in tles])
    jd0, fr0 = _jd(start)
    fr = fr0 + np.arange(n_seconds) / 86400.0
    jd = np.full(n_seconds, jd0)
    err, r_teme, _ = sats.sgp4(jd, fr)  # (S, T, 3)
    theta = _gmst_rad(jd + fr)  # rotate TEME -> ECEF (polar motion ignored)
    c, s = np.cos(theta), np.sin(theta)
    x = c * r_teme[..., 0] + s * r_teme[..., 1]
    y = -s * r_teme[..., 0] + c * r_teme[..., 1]
    pos = np.stack([x, y, r_teme[..., 2]], axis=-1)
    pos[err != 0] = np.nan
    alt = np.nanmean(np.linalg.norm(pos, axis=-1), axis=1) - R_EARTH_KM
    return pos, alt


def _longest_run(mask: np.ndarray) -> np.ndarray:
    """Longest run of True along the last axis."""
    best = np.zeros(mask.shape[:-1], dtype=int)
    cur = np.zeros_like(best)
    for t in range(mask.shape[-1]):
        cur = np.where(mask[..., t], cur + 1, 0)
        best = np.maximum(best, cur)
    return best


def screen_tles(tles, start: datetime, window_s: int, lat: float, lon: float,
                min_elev: float = 55.0, min_vis_s: int = 90, alt_range=(520.0, 580.0)):
    """Screening used in Sec. V-A: altitude band, min elevation, continuous visibility."""
    pos, alt = propagate_tle(tles, start, window_s)
    el, _ = _elev_range(pos, lat, lon)
    el = np.nan_to_num(el, nan=-90.0)
    ok_alt = (alt >= alt_range[0]) & (alt <= alt_range[1])
    run = _longest_run(el >= min_elev)
    keep = np.where(ok_alt & (run >= min_vis_s))[0]
    return keep, el[keep]


@dataclass
class LEOGeometry:
    """Per-second elevation/slant range of L satellites over a window."""
    elev_deg: np.ndarray   # (L, T)
    range_km: np.ndarray   # (L, T)
    min_elev: float
    source: str

    @property
    def n_sats(self) -> int:
        return self.elev_deg.shape[0]

    @property
    def window(self) -> int:
        return self.elev_deg.shape[1]

    def visible(self, t: int) -> np.ndarray:
        return self.elev_deg[:, t % self.window] >= self.min_elev

    def mean_visible(self) -> float:
        return float((self.elev_deg >= self.min_elev).sum(axis=0).mean())


def tle_geometry(tle_path: str | Path, start_iso: str, window_s: int, lat: float, lon: float,
                 min_elev: float) -> LEOGeometry:
    tles = load_tle(tle_path)
    start = datetime.fromisoformat(start_iso).replace(tzinfo=timezone.utc)
    pos, _ = propagate_tle(tles, start, window_s)
    el, rng = _elev_range(pos, lat, lon)
    el = np.nan_to_num(el, nan=-90.0)
    rng = np.nan_to_num(rng, nan=1e5)
    return LEOGeometry(el, rng, min_elev, f"TLE:{Path(tle_path).name}")


def synthetic_geometry(n_sats: int, window_s: int, min_elev: float, seed: int = 0,
                       alt_range=(520.0, 580.0)) -> LEOGeometry:
    """Fallback when sgp4/TLE is unavailable: straight-overhead-ish circular passes.

    Each satellite follows a great-circle pass whose closest approach and timing are random,
    reproducing short (~2-4 min) high-elevation passes similar to the TLE screening.
    """
    rng_ = np.random.default_rng(seed)
    t = np.arange(window_s)
    el = np.empty((n_sats, window_s))
    rg = np.empty((n_sats, window_s))
    for s in range(n_sats):
        h = rng_.uniform(*alt_range)
        r = R_EARTH_KM + h
        w = math.sqrt(MU_EARTH / r ** 3)  # rad/s
        t0 = rng_.uniform(0, window_s)
        cross = rng_.uniform(0.0, 0.035)  # cross-track offset angle (rad)
        along = w * (t - t0)
        # central angle between sub-satellite point and ground point
        cang = np.arccos(np.clip(np.cos(along) * np.cos(cross), -1, 1))
        d = np.sqrt(R_EARTH_KM ** 2 + r ** 2 - 2 * R_EARTH_KM * r * np.cos(cang))
        sin_el = (r * np.cos(cang) - R_EARTH_KM) / d
        el[s] = np.degrees(np.arcsin(np.clip(sin_el, -1, 1)))
        rg[s] = d
    return LEOGeometry(el, rg, min_elev, "synthetic")


def build_geometry(cfg: dict, root: Path) -> LEOGeometry:
    """Use TLE + sgp4 when available, otherwise the synthetic fallback."""
    leo = cfg["leo"]
    tle_path = root / leo["tle_file"]
    if leo.get("use_tle", True) and tle_path.exists():
        try:
            return tle_geometry(tle_path, leo["window_start_utc"], leo["window_s"],
                                cfg["area"]["lat"], cfg["area"]["lon"], leo["min_elev_deg"])
        except ImportError:
            print("[orbits] sgp4 not installed; using synthetic LEO geometry")
    return synthetic_geometry(leo["n_sats"], leo["window_s"], leo["min_elev_deg"], seed=leo.get("seed", 0))
'@

Write-ProjectFile 'src\satecn\policy.py' @'
"""Compact linear policies pi_theta(a|x) for each RL domain (Table II).

theta = [softmax logits for executor categories (reference category fixed at 0) | logit-space means of
continuous resource controls], each head linear in phi(x) = [1, AoI/a_norm, D_rem/d_norm].
Continuous controls (CPU share, remote CPU share, transmit-power share) are logit-normal:
z ~ N(w.phi, sigma^2), a = sigmoid(z) in (0, 1), so no clipping flattens the gradient.
"""
from __future__ import annotations

import numpy as np

from .domains import N_FEAT, DomainSpec
from .environment import CAT_CODE, LEO, UAV


def features(state: np.ndarray, cfg: dict) -> np.ndarray:
    a = np.clip(state[:, 0] / cfg["sim"]["aoi_norm"], 0, 3)
    d = np.clip(state[:, 1] / cfg["sim"]["drem_norm_mb"], 0, 3)
    return np.stack([np.ones_like(a), a, d], axis=1)


class LinearPolicy:
    def __init__(self, spec: DomainSpec, sigma: float):
        self.spec = spec
        self.sigma = sigma
        self.n_logit = 0 if spec.assigned else max(len(spec.cats), 1) - 1
        self.codes = np.array([CAT_CODE[c] for c in spec.cats])
        self.d = spec.dim

    def act(self, theta: np.ndarray, phi: np.ndarray, rng: np.random.Generator, assign=None, greedy=False):
        """Sample actions for all IoTs. Returns (env action dict, grad log pi of shape (n, d))."""
        n = phi.shape[0]
        grad = np.zeros((n, self.d))
        act = {"cat": np.full(n, self.codes[0] if len(self.codes) else LEO), "eps": np.zeros(n),
               "eps_o": np.ones(n), "p": np.ones(n)}
        off = 0
        if self.n_logit > 0:
            W = theta[: self.n_logit * N_FEAT].reshape(self.n_logit, N_FEAT)
            z = np.concatenate([np.zeros((n, 1)), phi @ W.T], axis=1)
            z -= z.max(axis=1, keepdims=True)
            pr = np.exp(z)
            pr /= pr.sum(axis=1, keepdims=True)
            if greedy:
                k = pr.argmax(axis=1)
            else:
                k = (pr.cumsum(axis=1) > rng.random((n, 1))).argmax(axis=1)
            onehot = np.zeros_like(pr)
            onehot[np.arange(n), k] = 1.0
            g = (onehot - pr)[:, 1:]                       # d log softmax / d logits
            grad[:, : self.n_logit * N_FEAT] = (g[:, :, None] * phi[:, None, :]).reshape(n, -1)
            act["cat"] = self.codes[k]
        off = self.n_logit * N_FEAT
        if self.spec.assigned:
            act["cat"] = assign.copy()
        for name in self.spec.cont:
            w = theta[off: off + N_FEAT]
            mu = phi @ w
            z = mu if greedy else mu + self.sigma * rng.standard_normal(n)
            gw = ((z - mu) / self.sigma ** 2)[:, None] * phi
            a = 1.0 / (1.0 + np.exp(-z))
            if name in ("p_uav", "p_leo"):
                mask = assign == (UAV if name == "p_uav" else LEO)
                act["p"] = np.where(mask, a, act["p"])
                grad[:, off: off + N_FEAT] = gw * mask[:, None]
            else:
                act[name] = a
                grad[:, off: off + N_FEAT] = gw
            off += N_FEAT
        return act, grad
'@

Write-ProjectFile 'src\satecn\trainer.py' @'
"""Training loops for NAC, MSR-NAC, MSR-NAC-ELLA and MSR-NAC-CDLL (Alg. 1) over a task stream."""
from __future__ import annotations

import time

import numpy as np

from .domains import DOMAINS
from .learners import hessian_from_fisher, msr_nac, nac_episodic, natural_step, rollout
from .lifelong import KnowledgeBase
from .policy import LinearPolicy

ALGOS = ("msr_nac_cdll", "msr_nac_ella", "msr_nac", "nac")
LABELS = {"msr_nac_cdll": "MSR-NAC-CDLL", "msr_nac_ella": "MSR-NAC-ELLA", "msr_nac": "MSR-NAC", "nac": "NAC",
          "exhaustive": "Exhaustive search"}


class Agent:
    """SAT-SDNC learning agent holding either per-task policies or a knowledge base."""

    def __init__(self, algo: str, cfg: dict, seed: int, kb: KnowledgeBase | None = None):
        assert algo in ALGOS, algo
        self.algo, self.cfg = algo, cfg
        self.rng = np.random.default_rng(seed)
        self.lc = cfg["learner"]
        self.sigma = cfg["policy"]["sigma"]
        self.policies = {g: LinearPolicy(DOMAINS[g], self.sigma) for g in DOMAINS}
        self.theta: dict[int, np.ndarray] = {}
        self.iters: dict[int, int] = {}
        self.kb = kb
        if algo in ("msr_nac_cdll", "msr_nac_ella") and kb is None:
            dims = {g: DOMAINS[g].dim for g in DOMAINS}
            self.kb = KnowledgeBase(dims, cfg["lifelong"], self.rng, cross_domain=(algo == "msr_nac_cdll"))

    @property
    def lifelong(self) -> bool:
        return self.kb is not None

    def ensure_task(self, task):
        if task.kid in self.iters:
            return
        self.iters[task.kid] = 0
        if self.lifelong:
            self.kb.add_task(task.kid, task.gid)
        else:
            self.theta[task.kid] = self.rng.uniform(0, self.cfg["policy"]["init_scale"], DOMAINS[task.gid].dim)

    def current_theta(self, task) -> np.ndarray:
        self.ensure_task(task)
        return self.kb.theta(task.kid) if self.lifelong else self.theta[task.kid]

    def train_step(self, task, geom, learn=True):
        """One iteration on task k: collect trajectories, PG step, KB update. Returns metrics."""
        th = self.current_theta(task)
        pol = self.policies[task.gid]
        batch = rollout(self.cfg, geom, task, pol, th, self.rng, n_episodes=self.lc["episodes_per_iter"])
        if not learn:
            return batch["metrics"]
        lc = self.lc
        if self.algo == "nac":
            w, F = nac_episodic(batch, lc["gamma"], lc["ridge"])
        else:
            w, F = msr_nac(batch, lc["gamma"], lc["n_step"], lc["ridge"])
        step = lc["step_size"] * lc["step_decay"] ** self.iters[task.kid]
        theta_hat = natural_step(th, w, F, step)
        if self.lifelong:
            self.kb.update(task.kid, theta_hat, hessian_from_fisher(F, self.cfg["lifelong"]["hessian_reg"]))
        else:
            self.theta[task.kid] = theta_hat
        self.iters[task.kid] += 1
        return batch["metrics"]

    def evaluate(self, task, geom, n_episodes=3, slots=None, seed=None):
        rng = np.random.default_rng(seed if seed is not None else self.rng.integers(1 << 31))
        return rollout(self.cfg, geom, task, self.policies[task.gid], self.current_theta(task), rng,
                       n_episodes=n_episodes, slots=slots)["metrics"]


def train_stream(agent: Agent, tasks, geom, iterations: int, log_every: int = 20, tag: str = ""):
    """Interleaved lifelong training: every iteration visits all tasks in random order."""
    hist = {t.kid: {"penalty": [], "aoi": [], "energy": []} for t in tasks}
    t0 = time.time()
    for it in range(iterations):
        for idx in agent.rng.permutation(len(tasks)):
            task = tasks[idx]
            m = agent.train_step(task, geom)
            for k in ("penalty", "aoi", "energy"):
                hist[task.kid][k].append(m[k])
        if log_every and (it + 1) % log_every == 0:
            avg = np.mean([hist[t.kid]["penalty"][-1] for t in tasks])
            print(f"[{tag}{LABELS[agent.algo]}] iter {it + 1}/{iterations} mean penalty {avg:.2f} "
                  f"({time.time() - t0:.0f}s)", flush=True)
    return hist
'@

Write-ProjectFile 'tests\test_core.py' @'
"""Unit tests: run with  python -m pytest -q  (or  python tests/test_core.py)."""
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from satecn.config import load_config  # noqa: E402
from satecn.domains import DOMAINS, make_task_set  # noqa: E402
from satecn.environment import LEO, LOCAL, SATECNEnv  # noqa: E402
from satecn.lifelong import KnowledgeBase, lasso_quadratic  # noqa: E402
from satecn.orbits import synthetic_geometry  # noqa: E402
from satecn.policy import LinearPolicy  # noqa: E402

CFG = load_config()
GEOM = synthetic_geometry(18, 600, 55.0, seed=1)


def test_domain_dimensions():
    # heterogeneous policy dimensions d_g of Table II domains
    assert [DOMAINS[g].dim for g in range(1, 7)] == [6, 6, 3, 6, 12, 15]


def test_env_invariants():
    task = make_task_set(CFG, 0, 1, domains=(6,))[0]
    env = SATECNEnv(CFG, GEOM, task, seed=0)
    s = env.reset()
    n = env.n
    for t in range(60):
        cat = np.where(np.arange(n) % 2 == 0, LOCAL, LEO)
        prev = s[:, 0].copy()
        s, c, e = env.step({"cat": cat, "eps": np.full(n, .7), "eps_o": np.ones(n), "p": np.ones(n)})
        assert np.all(e >= 0) and np.all(np.isfinite(c))
        assert np.all(s[:, 0] <= prev + 1 + 1e-9)          # Eq. (14): AoI grows by at most one per slot
        assert np.all(s[:, 1] >= -1e-9)                      # remaining data is non-negative (Eq. 12)
    st = env.stats
    assert st["done_iot"] + st["done_uav"] + st["done_leo"] <= st["gen"]


def test_policy_score_function():
    """grad log pi from the policy equals a finite-difference of log pi (softmax + logit-normal heads)."""
    spec = DOMAINS[6]
    pol = LinearPolicy(spec, sigma=0.5)
    rng = np.random.default_rng(3)
    theta = rng.normal(size=spec.dim)
    phi = np.array([[1.0, 0.4, 0.2]])

    def logp(th, cat_idx, z):
        W = th[:6].reshape(2, 3)
        logits = np.concatenate([[0.0], W @ phi[0]])
        lp = logits[cat_idx] - np.log(np.exp(logits).sum())
        for j in range(3):
            mu = th[6 + 3 * j: 9 + 3 * j] @ phi[0]
            lp += -0.5 * ((z[j] - mu) / 0.5) ** 2
        return lp

    act, g = pol.act(theta, phi, np.random.default_rng(11))
    cat_idx = list(pol.codes).index(act["cat"][0])
    z = [np.log(act[k][0] / (1 - act[k][0])) for k in ("eps", "eps_o", "p")]
    num = np.zeros(spec.dim)
    for i in range(spec.dim):
        d = np.zeros(spec.dim)
        d[i] = 1e-6
        num[i] = (logp(theta + d, cat_idx, z) - logp(theta - d, cat_idx, z)) / 2e-6
    assert np.allclose(num, g[0], atol=1e-4)


def test_lasso_kkt():
    rng = np.random.default_rng(0)
    A = rng.normal(size=(10, 5))
    Q = A.T @ A
    b = rng.normal(size=5)
    mu = 0.5
    s = lasso_quadratic(Q, b, mu, np.zeros(5), iters=2000, tol=1e-12)
    grad = 2 * (Q @ s - b)
    for j in range(5):  # KKT conditions of min s'Qs - 2b's + mu|s|_1
        if abs(s[j]) > 1e-8:
            assert abs(grad[j] + mu * np.sign(s[j])) < 1e-5
        else:
            assert abs(grad[j]) <= mu + 1e-5


def test_kb_fits_shared_structure():
    """CDLL KB recovers policies generated from a shared low-rank basis across two domains."""
    rng = np.random.default_rng(1)
    lcfg = dict(CFG["lifelong"], h=3, d_base=6, kb_steps=50, mu1=1e-4)
    kb = KnowledgeBase({1: 6, 6: 15}, lcfg, rng, cross_domain=True)
    Ltrue = rng.normal(size=(6, 3))
    P = {1: rng.normal(size=(6, 6)) / 2, 6: rng.normal(size=(15, 6)) / 2}
    for k in range(8):
        g = 1 if k % 2 else 6
        kb.add_task(k, g)
    err0 = None
    for it in range(40):
        for k in range(8):
            g = kb.tasks[k]["g"]
            th = P[g] @ Ltrue @ np.array([1.0, -0.5, 0.3]) * (1 + 0.2 * k)
            kb.update(k, th, np.eye(len(th)))
        if err0 is None:
            err0 = kb.recon_error()
    assert kb.recon_error() < 0.5 * err0


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("PASS", name)
'@

Write-Host "SATECN-CDLL project: 22 files written"
